#!/bin/bash
docker build --tag tarea_1 .
