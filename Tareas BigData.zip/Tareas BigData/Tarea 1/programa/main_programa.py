
import funciones

# Carga inicial de datos
# ======================================================================

# Carga del csv de ciclistas
# ----------------------------------------------------------------------

funciones.data_loader_ciclistas("ciclista.csv")




# Carga del csv de rutas
# ----------------------------------------------------------------------
schema_ruta = StructType([StructField('ruta_id', IntegerType()),
                        StructField('nombre_ruta', StringType()),
                        StructField('kilometros', FloatType()),
                        ])

df_rutas = spark.read.csv("ruta.csv",
                        schema=schema_ruta,
                        header=False)
df_rutas.show()

# Carga del csv de actividades
# ---------------------------------------------------------------------------------------------------
schema_actividades = StructType([StructField('ruta_id', IntegerType()),
                        StructField('ciclista_id', IntegerType()),
                        StructField('fecha', TimestampType()),
                        ])

df_actividades = spark.read.csv("actividad.csv",
                                schema=schema_actividades,
                                header=False)
df_actividades.show()

# Incluir una nueva columna con el formateo de la fecha original
formatted_df = df_actividades.withColumn("fecha",
                                    date_format(col("fecha"),'yyyy/MM/dd'))
formatted_df.show()


# Crea una funcion definida por el usuario (user defined function udf)
string_to_date = \
    udf(lambda text_date: datetime.strptime(text_date, '%Y/%m/%d'),
        DateType())

typed_df = formatted_df.withColumn("fecha", string_to_date(formatted_df.fecha))
typed_df.show()
typed_df.printSchema()


# Unión de tabla typed_df con la información de la provincia de cada ciclista
df_activ_provin = typed_df.join(df_ciclistas, on="ciclista_id", how="inner")
df_activ_provin.sort("ciclista_id").show()

# Unión de df_activ_provin con la información de kilometraje de cada ruta
df_activ_provin_rutas = df_activ_provin.join(df_rutas, on="ruta_id", how="inner")
df_activ_provin_rutas.show()

# DataFrame intermedio de kilómetros totales recorridos por ciclista
df_km_t_ciclista = df_activ_provin_rutas.groupBy("nombre_ciclista") \
                    .agg(round(sum("kilometros"),2).alias("ciclista_kmt")) \
                    .sort(desc("ciclista_kmt")) \

df_km_t_ciclista.show()

# DataFrame intermedio de kilómetros promedio recorridos por ciclista
df_km_p_ciclista = df_activ_provin_rutas.groupBy("nombre_ciclista") \
                    .agg(round(avg("kilometros"),2).alias("ciclista_kmp")) \
                    .sort(desc("ciclista_kmp")) \

df_km_p_ciclista.show()

# DataFrame intermedio de kilómetros totales recorridos por ruta
df_km_t_ruta = df_activ_provin_rutas.groupBy("nombre_ruta") \
                .agg(round(sum("kilometros"),2).alias("ruta_kmt")) \
                .sort(desc("ruta_kmt")) \

df_km_t_ruta.show()

# DataFrame intermedio de kilómetros promedio recorridos por ruta
df_km_p_ruta = df_activ_provin_rutas.groupBy("nombre_ruta") \
                .agg(round(avg("kilometros"),2).alias("ruta_kmp")) \
                .sort(desc("ruta_kmp")) \

df_km_p_ruta.show()

# DataFrame intermedio de kilómetros totales recorridos por día
df_km_t_dia = df_activ_provin_rutas.groupBy("fecha") \
                .agg(round(sum("kilometros"),2).alias("fecha_kmt")) \
                .sort(desc("fecha_kmt")) \

df_km_t_dia.show()

# DataFrame intermedio de kilómetros promedio recorridos por día
df_km_p_dia = df_activ_provin_rutas.groupBy("fecha") \
                .agg(round(avg("kilometros"),2).alias("fecha_kmp")) \
                .sort(desc("fecha_kmp")) \

df_km_p_dia.show()

# DataFrame intermedio de kilómetros totales recorridos por provincia
df_km_t_provincia = df_activ_provin_rutas.groupBy("provincia") \
                    .agg(round(sum("kilometros"),2).alias("provincia_kmt")) \
                    .sort(desc("provincia_kmt")) \

df_km_t_provincia.show()

# DataFrame intermedio de kilómetros promedio recorridos por provincia
df_km_p_provincia = df_activ_provin_rutas.groupBy("provincia") \
                    .agg(round(avg("kilometros"),2).alias("provincia_kmp")) \
                    .sort(desc("provincia_kmp")) \

df_km_p_provincia.show()

# Determinación del top 5 por provincia (total de kilómetros)
df_km_t_provincia.show(5)

# Determinación del top 5 por provincia (kilómetros promedio)
df_km_p_provincia.show(5)
