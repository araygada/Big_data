from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, date_format, udf, sum, count, avg, mean, desc, round
from pyspark.sql.types import (DateType, IntegerType, FloatType, StructField,
                               StructType, TimestampType, StringType)
import funciones

spark = SparkSession.builder.appName("Ciclismo").getOrCreate()

print("\n")
print("=" * 87)
print("Este programa se basa en informacion sobre 44 ciclistas y permite establecer ")
print("el top n de los resultados de los deportistas tanto en kilometros totales ")
print("como en promedio de kilometros diarios \n")


mensaje = "Indique un numero entre 1 y 44 para determinar la clasificacion top correspondiente:"

def nTop(message):

    ans = 0
    while not ans:
        try:
            ans = int(input(message))
            if ans < 1 or ans > 44:
                raise ValueError
        except ValueError:
            ans = 0
            print("Esa no es una opcion valida!")
    return ans


#myTop = nTop(mensaje)

#print(f"El numero de top es: {myTop}")

# Carga del csv de ciclistas
# ---------------------------------------------------------------------------------------------------
schema_ciclista = StructType([StructField('ciclista_id', IntegerType()),
                        StructField('nombre_ciclista', StringType()),
                        StructField('provincia', StringType()),
                        ])

df_ciclistas = spark.read.csv("ciclista.csv",
                            schema=schema_ciclista,
                            header=False)
df_ciclistas.show()

# Carga del csv de rutas
# ---------------------------------------------------------------------------------------------------
schema_ruta = StructType([StructField('ruta_id', IntegerType()),
                        StructField('nombre_ruta', StringType()),
                        StructField('kilometros', FloatType()),
                        ])

df_rutas = spark.read.csv("ruta.csv",
                        schema=schema_ruta,
                        header=False)
df_rutas.show()

# Carga del csv de actividades
# ---------------------------------------------------------------------------------------------------
schema_actividades = StructType([StructField('ruta_id', IntegerType()),
                        StructField('ciclista_id', IntegerType()),
                        StructField('fecha', TimestampType()),
                        ])

df_actividades = spark.read.csv("actividad.csv",
                                schema=schema_actividades,
                                header=False)
df_actividades.show()

# Incluir una nueva columna con el formateo de la fecha original
formatted_df = df_actividades.withColumn("fecha",
                                    date_format(col("fecha"),'yyyy/MM/dd'))
formatted_df.show()


# Crea una funcion definida por el usuario (user defined function udf)
string_to_date = \
    udf(lambda text_date: datetime.strptime(text_date, '%Y/%m/%d'),
        DateType())

typed_df = formatted_df.withColumn("fecha", string_to_date(formatted_df.fecha))
typed_df.show()
typed_df.printSchema()


# Unión de tabla typed_df con la información de la provincia de cada ciclista
df_activ_provin = typed_df.join(df_ciclistas, on="ciclista_id", how="inner")
df_activ_provin.sort("ciclista_id").show()

# Unión de df_activ_provin con la información de kilometraje de cada ruta
df_activ_provin_rutas = df_activ_provin.join(df_rutas, on="ruta_id", how="inner")
df_activ_provin_rutas.show()

# DataFrame intermedio de kilómetros totales recorridos por ciclista
df_km_t_ciclista = df_activ_provin_rutas.groupBy("nombre_ciclista") \
                    .agg(round(sum("kilometros"),2).alias("ciclista_kmt")) \
                    .sort(desc("ciclista_kmt")) \

df_km_t_ciclista.show()

# DataFrame intermedio de kilómetros promedio recorridos por ciclista
df_km_p_ciclista = df_activ_provin_rutas.groupBy("nombre_ciclista") \
                    .agg(round(avg("kilometros"),2).alias("ciclista_kmp")) \
                    .sort(desc("ciclista_kmp")) \

df_km_p_ciclista.show()

# DataFrame intermedio de kilómetros totales recorridos por ruta
df_km_t_ruta = df_activ_provin_rutas.groupBy("nombre_ruta") \
                .agg(round(sum("kilometros"),2).alias("ruta_kmt")) \
                .sort(desc("ruta_kmt")) \

df_km_t_ruta.show()

# DataFrame intermedio de kilómetros promedio recorridos por ruta
df_km_p_ruta = df_activ_provin_rutas.groupBy("nombre_ruta") \
                .agg(round(avg("kilometros"),2).alias("ruta_kmp")) \
                .sort(desc("ruta_kmp")) \

df_km_p_ruta.show()

# DataFrame intermedio de kilómetros totales recorridos por día
df_km_t_dia = df_activ_provin_rutas.groupBy("fecha") \
                .agg(round(sum("kilometros"),2).alias("fecha_kmt")) \
                .sort(desc("fecha_kmt")) \

df_km_t_dia.show()

# DataFrame intermedio de kilómetros promedio recorridos por día
df_km_p_dia = df_activ_provin_rutas.groupBy("fecha") \
                .agg(round(avg("kilometros"),2).alias("fecha_kmp")) \
                .sort(desc("fecha_kmp")) \

df_km_p_dia.show()

# DataFrame intermedio de kilómetros totales recorridos por provincia
df_km_t_provincia = df_activ_provin_rutas.groupBy("provincia") \
                    .agg(round(sum("kilometros"),2).alias("provincia_kmt")) \
                    .sort(desc("provincia_kmt")) \

df_km_t_provincia.show()

# DataFrame intermedio de kilómetros promedio recorridos por provincia
df_km_p_provincia = df_activ_provin_rutas.groupBy("provincia") \
                    .agg(round(avg("kilometros"),2).alias("provincia_kmp")) \
                    .sort(desc("provincia_kmp")) \

df_km_p_provincia.show()

# Determinación del top 5 por provincia (total de kilómetros)
df_km_t_provincia.show(5)

# Determinación del top 5 por provincia (kilómetros promedio)
df_km_p_provincia.show(5)
