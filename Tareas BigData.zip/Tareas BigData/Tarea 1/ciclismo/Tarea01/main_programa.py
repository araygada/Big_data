
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, date_format, udf, sum, count, avg, mean, desc, round
from pyspark.sql import Window
from pyspark.sql.types import (DateType, IntegerType, FloatType, StructField,
                               StructType, TimestampType, StringType)

from funciones import joiner, aggregater, aggregater_filter

spark = SparkSession.builder.appName("Ciclismo").getOrCreate()


# Carga inicial de datos
# ===================================================================================================

# Carga del csv de ciclistas
# ---------------------------------------------------------------------------------------------------
schema_ciclista = StructType([StructField('ciclista_id', IntegerType()),
                        StructField('nombre_ciclista', StringType()),
                        StructField('provincia', StringType()),
                        ])

df_ciclistas = spark.read.csv("ciclista.csv",
                            schema=schema_ciclista,
                            header=False)
df_ciclistas.show()

# Carga del csv de rutas
# ---------------------------------------------------------------------------------------------------
schema_ruta = StructType([StructField('ruta_id', IntegerType()),
                        StructField('nombre_ruta', StringType()),
                        StructField('kilometros', FloatType()),
                        ])

df_rutas = spark.read.csv("ruta.csv",
                        schema=schema_ruta,
                        header=False)
df_rutas.show()

# Carga del csv de actividades
# ---------------------------------------------------------------------------------------------------
schema_actividades = StructType([StructField('ruta_id', IntegerType()),
                        StructField('ciclista_id', IntegerType()),
                        StructField('fecha', TimestampType()),
                        ])

df_actividades = spark.read.csv("actividad.csv",
                                schema=schema_actividades,
                                header=False)
df_actividades.show()

# Incluir una nueva columna con el formateo de la fecha original
formatted_df = df_actividades.withColumn("fecha",
                                    date_format(col("fecha"),'yyyy/MM/dd'))
formatted_df.show()


# Crea una funcion definida por el usuario (user defined function udf)
string_to_date = \
    udf(lambda text_date: datetime.strptime(text_date, '%Y/%m/%d'),
        DateType())

typed_df = formatted_df.withColumn("fecha", string_to_date(formatted_df.fecha))
typed_df.show()
typed_df.printSchema()


# Creación de dataframes de unión de los tres csv de ciclistas, rutas y actividades
# ===================================================================================================

# Unión de tabla typed_df con la información de la provincia de cada ciclista
dataFrame1 = typed_df
dataFrame2 = df_ciclistas
columna = "ciclista_id"
tipo = "inner"
df_activ_provin = joiner(dataFrame1, dataFrame2, columna, tipo)
df_activ_provin.show()

# Unión de df_activ_provin con la información de kilometraje de cada ruta
dataFrame1 = df_activ_provin
dataFrame2 = df_rutas
columna = "ruta_id"
tipo = "inner"
df_activ_provin_rutas = joiner(dataFrame1, dataFrame2, columna, tipo)
df_activ_provin_rutas.show()

# Creación de dataframes intermedios
# ===================================================================================================

# DataFrame intermedio de kilómetros totales recorridos por ciclista filtrado por provincia
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "nombre_ciclista"
operacion = sum
col_oper = "kilometros"
alias = "ciclista_kmt"
sort= desc
df_km_t_ciclista = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_t_ciclista.show()

# DataFrame intermedio de kilómetros promedio recorridos por ciclista
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "nombre_ciclista"
operacion = avg
col_oper = "kilometros"
alias = "ciclista_kmp"
sort= desc
df_km_p_ciclista = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_p_ciclista.show()


# DataFrame intermedio de kilómetros promedio recorridos por ciclista
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "nombre_ciclista"
operacion = avg
col_oper = "kilometros"
alias = "ciclista_kmp"
sort= desc
df_km_p_ciclista = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_p_ciclista.show()

# DataFrame intermedio de kilómetros totales recorridos por ruta
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "nombre_ruta"
operacion = sum
col_oper = "kilometros"
alias = "ruta_kmt"
sort= desc
df_km_t_ruta = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_t_ruta.show()

# DataFrame intermedio de kilómetros promedio recorridos por ruta
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "nombre_ruta"
operacion = avg
col_oper = "kilometros"
alias = "ruta_kmp"
sort= desc
df_km_p_ruta = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_p_ruta.show()

# DataFrame intermedio de kilómetros totales recorridos por día
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "fecha"
operacion = sum
col_oper = "kilometros"
alias = "fecha_kmt"
sort= desc
df_km_t_dia = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_t_dia.show()

# DataFrame intermedio de kilómetros promedio recorridos por día
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "fecha"
operacion = avg
col_oper = "kilometros"
alias = "fecha_kmp"
sort= desc
df_km_p_dia = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_p_dia.show()

# DataFrame intermedio de kilómetros totales recorridos por provincia
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "provincia"
operacion = sum
col_oper = "kilometros"
alias = "provincia_kmt"
sort= desc
df_km_t_provincia = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_t_provincia.show()

# DataFrame intermedio de kilómetros promedio recorridos por provincia
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "provincia"
operacion = avg
col_oper = "kilometros"
alias = "provincia_kmp"
sort= desc
df_km_p_provincia = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_km_p_provincia.show()


# Dataframes de resultados finales según el top n definido ciclista por provincia seleccionada
# ===================================================================================================

myTop = 3

# Determinación del top de ciclistas por provincia (total de kilómetros)
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "nombre_ciclista"
operacion = sum
col_oper = "kilometros"
alias = "ciclista_kmt"
sort= desc
col_filter = "provincia"
filter = "San José"

df_km_t_ciclista_provincia = aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, myTop)

df_km_t_ciclista_provincia.show()

# Determinación del top n de ciclistas por provincia (kilómetros promedio)
# ---------------------------------------------------------------------------------------------------
dataFrame = df_activ_provin_rutas
col_group = "nombre_ciclista"
operacion = avg
col_oper = "kilometros"
alias = "ciclista_kmp"
sort= desc
col_filter = "provincia"
filter = "San José"

df_km_p_ciclista_provincia = aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, myTop)

df_km_p_ciclista_provincia.show()
