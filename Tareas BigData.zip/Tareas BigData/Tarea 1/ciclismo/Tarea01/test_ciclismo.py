import pytest

from .funciones import *

# Test 1
# ---------------------------------------------------------------------------------------------
def test_join_actividades_provincias_01(spark_session):
    actividades_data = [(1, 1160892, "2019-12-01"),
                        (3, 1160892, "2019-12-03"),
                        ]
    actividades_df = spark_session.createDataFrame(actividades_data,
                                              ['ruta_id', 'ciclista_id', 'fecha'])
       
    provincias_data = [(1160892,"Joseph Chavarria", "San José")]
    provincias_df = spark_session.createDataFrame(provincias_data,
                                              ['ciclista_id', 'nombre_ciclista', 'provincia'])
    actividades_df.show()
    provincias_df.show()

    columna = "ciclista_id"
    tipo = "inner"
    actual_ds = joiner(actividades_df, provincias_df, columna, tipo)

    expected_ds = spark_session.createDataFrame(
        [
            (1160892, 1, "2019-12-01", 'Joseph Chavarria', "San José"),
            (1160892, 3, "2019-12-03", 'Joseph Chavarria', "San José"),
        ],
        ['ciclista_id', 'ruta_id', 'fecha', 'nombre_ciclista', 'provincia'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 2
# ---------------------------------------------------------------------------------------------
def test_join_actividades_provincias_02(spark_session):
    actividades_data = [(1, 1160892, "2019-12-01"),
                        (3, 1160892, "2019-12-03"),
                        (3, 1160892, "2019-12-03"),
                        ]
    actividades_df = spark_session.createDataFrame(actividades_data,
                                              ['ruta_id', 'ciclista_id', 'fecha'])
       
    provincias_data = [(1160892,"Joseph Chavarria", "San José")]
    provincias_df = spark_session.createDataFrame(provincias_data,
                                              ['ciclista_id', 'nombre_ciclista', 'provincia'])
    actividades_df.show()
    provincias_df.show()

    columna = "ciclista_id"
    tipo = "inner"
    actual_ds = joiner(actividades_df, provincias_df, columna, tipo)

    expected_ds = spark_session.createDataFrame(
        [
            (1160892, 1, "2019-12-01", 'Joseph Chavarria', "San José"),
            (1160892, 3, "2019-12-03", 'Joseph Chavarria', "San José"),
            (1160892, 3, "2019-12-03", 'Joseph Chavarria', "San José"),
        ],
        ['ciclista_id', 'ruta_id', 'fecha', 'nombre_ciclista', 'provincia'])

    assert actual_ds.collect() == expected_ds.collect()
    
# Test 3
# ---------------------------------------------------------------------------------------------
def test_join_actividades_provincias_rutas_km_01(spark_session):
    activ_provincia_data =  [
                                (1160892, 1, "2019-12-01", 'Joseph Chavarria', "San José"),
                                (1160892, 3, "2019-12-03", 'Joseph Chavarria', "San José"),
                            ]
    activ_provincia_df = spark_session.createDataFrame(activ_provincia_data, 
                            ['ciclista_id', 'ruta_id', 'fecha', 'nombre_ciclista', 'provincia'])
       
    rutasKM_data =  [
                        (1, "Pavas – Cañas", 160.5),
                        (3, "La Cruz – Nicoya", 68.3),
                    ]
    rutasKM_df = spark_session.createDataFrame(rutasKM_data,
                                              ['ruta_id', 'nombre_ruta', 'kilometros'])
    
    activ_provincia_df.show()
    rutasKM_df.show()

    columna = "ruta_id"
    tipo = "inner"
    actual_ds = joiner(activ_provincia_df, rutasKM_df, columna, tipo)

    data_integrada =  ([
                        (1, 1160892,  "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                        (3, 1160892,  "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                    ])

    expected_ds = spark_session.createDataFrame(data_integrada, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 4
# ---------------------------------------------------------------------------------------------
def test_join_actividades_provincias_rutas_km_02(spark_session):
    activ_provincia_data =  [
                                (1160892, 1, "2019-12-01", 'Joseph Chavarria', "San José"),
                                (1160892, 3, "2019-12-03", 'Joseph Chavarria', "San José"),
                                (1160892, 3, "2019-12-03", 'Joseph Chavarria', "San José"),
                            ]
    activ_provincia_df = spark_session.createDataFrame(activ_provincia_data, 
                            ['ciclista_id', 'ruta_id', 'fecha', 'nombre_ciclista', 'provincia'])
       
    rutasKM_data =  [
                        (1, "Pavas – Cañas", 160.5),
                        (3, "La Cruz – Nicoya", 68.3),
                    ]
    rutasKM_df = spark_session.createDataFrame(rutasKM_data,
                                              ['ruta_id', 'nombre_ruta', 'kilometros'])
    
    activ_provincia_df.show()
    rutasKM_df.show()

    columna = "ruta_id"
    tipo = "inner"
    actual_ds = joiner(activ_provincia_df, rutasKM_df, columna, tipo)

    data_integrada =  ([
                        (1, 1160892,  "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                        (3, 1160892,  "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                        (3, 1160892,  "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                    ])

    expected_ds = spark_session.createDataFrame(data_integrada, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    assert actual_ds.collect() == expected_ds.collect()


# Test 5
# ---------------------------------------------------------------------------------------------
def test_aggegate_ciclistas_km_total(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = sum
    col_oper = "kilometros"
    alias = "ciclista_kmt"
    sort= desc
    actual_ds =  aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

    data_agregado = ([
                        ('Joseph Chavarria', 369.5),
                        ('Germán Loaiza', 349.2),
                        ('Luis Morera', 329.4)
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'ciclista_kmt'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 6
# ---------------------------------------------------------------------------------------------
def test_aggegate_ciclistas_km_promedio(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = avg
    col_oper = "kilometros"
    alias = "ciclista_kmp"
    sort= desc
    actual_ds =  aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

    data_agregado = ([
                        ('Joseph Chavarria', 123.17),
                        ('Germán Loaiza', 116.40),
                        ('Luis Morera', 109.80)
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'ciclista_kmp'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 7
# ---------------------------------------------------------------------------------------------
def test_aggegate_rutas_km_total(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ruta"
    operacion = sum
    col_oper = "kilometros"
    alias = "ruta_kmt"
    sort= desc
    actual_ds =  aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

    data_agregado = ([
                        ('Pavas – Cañas', 321.0),
                        ('Nicoya – Esparza', 281.4),
                        ('Cañas – La Cruz', 240.8),
                        ('La Cruz – Nicoya', 204.9)
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ruta', 'ruta_kmt'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 8
# ---------------------------------------------------------------------------------------------
def test_aggegate_rutas_km_total_filter(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = sum
    col_oper = "kilometros"
    alias = "ruta_kmt"
    sort= desc
    col_filter = "nombre_ruta"
    filter = "La Cruz – Nicoya"
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, 3)

    data_agregado = ([
                        ('Joseph Chavarria', 68.3),
                        ('Germán Loaiza', 68.3),
                        ('Luis Morera', 68.3),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'ruta_kmt'])

    assert actual_ds.collect() == expected_ds.collect()


# Test 9
# ---------------------------------------------------------------------------------------------
def test_aggegate_rutas_km_promedio(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ruta"
    operacion = avg
    col_oper = "kilometros"
    alias = "ruta_kmp"
    sort= desc
    actual_ds =  aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

    data_agregado = ([
                        ('Pavas – Cañas', 160.5),
                        ('Nicoya – Esparza', 140.7),
                        ('Cañas – La Cruz', 120.4),
                        ('La Cruz – Nicoya', 68.3)
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ruta', 'ruta_kmp'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 10
# ---------------------------------------------------------------------------------------------
def test_aggegate_rutas_km_promedio_filter(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = avg
    col_oper = "kilometros"
    alias = "ruta_kmp"
    sort= desc
    col_filter = "nombre_ruta"
    filter = "La Cruz – Nicoya"
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, 3)

    data_agregado = ([
                        ('Joseph Chavarria', 68.3),
                        ('Germán Loaiza', 68.3),
                        ('Luis Morera', 68.3),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'ruta_kmp'])

    assert actual_ds.collect() == expected_ds.collect()

    
# Test 11
# ---------------------------------------------------------------------------------------------
def test_aggegate_fechas_km_total(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "fecha"
    operacion = sum
    col_oper = "kilometros"
    alias = "fecha_kmt"
    sort= desc
    actual_ds =  aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

    data_agregado = ([
                        ('2019-12-01', 321.0),
                        ('2019-12-04', 281.4),
                        ('2019-12-02', 240.8),
                        ('2019-12-03', 204.9)
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['fecha', 'fecha_kmt'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 12
# ---------------------------------------------------------------------------------------------
def test_aggegate_fechas_km_total_filter(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = sum
    col_oper = "kilometros"
    alias = "fecha_kmt"
    sort= desc
    col_filter = "fecha"
    filter = '2019-12-03'
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, 3)

    data_agregado = ([
                        ('Joseph Chavarria', 68.3),
                        ('Germán Loaiza', 68.3),
                        ('Luis Morera', 68.3),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'fecha_kmt'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 13
# ---------------------------------------------------------------------------------------------
def test_aggegate_fechas_km_promedio(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "fecha"
    operacion = avg
    col_oper = "kilometros"
    alias = "fecha_kmp"
    sort= desc
    actual_ds =  aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

    data_agregado = ([
                        ('2019-12-01', 160.5),
                        ('2019-12-04', 140.7),
                        ('2019-12-02', 120.4),
                        ('2019-12-03', 68.3)
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['fecha', 'fecha_kmp'])

    assert actual_ds.collect() == expected_ds.collect()
    
# Test 14
# ---------------------------------------------------------------------------------------------
def test_aggegate_fechas_km_promedio_filter(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "San José", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "San José", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "San José", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "San José", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "San José", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = avg
    col_oper = "kilometros"
    alias = "fecha_kmp"
    sort= desc
    col_filter = "fecha"
    filter = "2019-12-03"
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, 3)

    data_agregado = ([
                        ('Joseph Chavarria', 68.3),
                        ('Germán Loaiza', 68.3),
                        ('Luis Morera', 68.3),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'fecha_kmp'])

    assert actual_ds.collect() == expected_ds.collect()


# Test 15
# ---------------------------------------------------------------------------------------------
def test_aggegate_provincias_km_total(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "Cartago", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "Cartago", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "Cartago", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "Heredia", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "Heredia", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "Heredia", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "provincia"
    operacion = sum
    col_oper = "kilometros"
    alias = "provincia_kmt"
    sort= desc
    actual_ds =  aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

    data_agregado = ([
                        ('San José', 369.50),
                        ('Heredia', 349.20),
                        ('Cartago', 329.40),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['provincia', 'provincia_kmt'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 16
# ---------------------------------------------------------------------------------------------
def test_aggegate_provincias_km_total_filter(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "Cartago", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "Cartago", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "Cartago", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "Heredia", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "Heredia", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "Heredia", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = sum
    col_oper = "kilometros"
    alias = "provincia_kmt"
    sort= desc
    col_filter = "provincia"
    filter = "Cartago"
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, 1)

    data_agregado = ([
                        ('Luis Morera', 329.40),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'provincia_kmt'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 17
# ---------------------------------------------------------------------------------------------
def test_aggegate_provincias_km_promedio(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "Cartago", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "Cartago", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "Cartago", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "Heredia", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "Heredia", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "Heredia", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "provincia"
    operacion = avg
    col_oper = "kilometros"
    alias = "provincia_kmp"
    sort= desc
    actual_ds =  aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

    data_agregado = ([
                        ('San José', 123.17),
                        ('Heredia', 116.40),
                        ('Cartago', 109.80),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['provincia', 'provincia_kmp'])

    assert actual_ds.collect() == expected_ds.collect()


# Test 18
# ---------------------------------------------------------------------------------------------
def test_aggegate_provincias_km_promedio_filter(spark_session):
    data =  ([
                (1, 1160892, "2019-12-01", 'Joseph Chavarria', "San José", "Pavas – Cañas", 160.5),
                (3, 1160892, "2019-12-03", 'Joseph Chavarria', "San José", "La Cruz – Nicoya", 68.3),
                (4, 1160892, "2019-12-04", 'Joseph Chavarria', "San José", "Nicoya – Esparza", 140.7),
                (2, 1346775, "2019-12-02", 'Luis Morera', "Cartago", "Cañas – La Cruz", 120.4),
                (3, 1346775, "2019-12-03", 'Luis Morera', "Cartago", "La Cruz – Nicoya", 68.3),
                (4, 1346775, "2019-12-04", 'Luis Morera', "Cartago", "Nicoya – Esparza", 140.7),
                (1, 1403104, "2019-12-01", 'Germán Loaiza', "Heredia", "Pavas – Cañas", 160.5),
                (2, 1403104, "2019-12-02", 'Germán Loaiza', "Heredia", "Cañas – La Cruz", 120.4),
                (3, 1403104, "2019-12-03", 'Germán Loaiza', "Heredia", "La Cruz – Nicoya", 68.3),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])

    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = avg
    col_oper = "kilometros"
    alias = "provincia_kmt"
    sort= desc
    col_filter = "provincia"
    filter = "Cartago"
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, 1)

    data_agregado = ([
                        ('Luis Morera', 109.80),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'provincia_kmt'])

    assert actual_ds.collect() == expected_ds.collect()


# Test 19
# ---------------------------------------------------------------------------------------------
def test_topn_ciclistas_provincia_total_top3(spark_session):
    
    data =  ([
                (1,1160892,"2019-12-01","Joseph Chavarria","San José","Pavas – Cañas",160.5),
                (6,1160892,"2019-12-06","Joseph Chavarria","San José","Paraíso – Paraíso",100.8),
                (2,1346775,"2019-12-02","Luis Morera","Cartago","Cañas – La Cruz",120.4),
                (4,1346775,"2019-12-04","Luis Morera","Cartago","Nicoya – Esparza",140.7),
                (10,1346775,"2019-12-10","Luis Morera","Cartago","Circuito Presidente",100.8),
                (1,1403104,"2019-12-01","Germán Loaiza","San José","Pavas – Cañas",160.5),
                (4,1403104,"2019-12-04","Germán Loaiza","San José","Nicoya – Esparza",140.7),
                (6,1403104,"2019-12-06","Germán Loaiza","San José","Paraíso – Paraíso",100.8),
                (2,1467497,"2019-12-02","Luis Espinoza","San José","Cañas – La Cruz",120.4),
                (4,1467497,"2019-12-04","Luis Espinoza","San José","Nicoya – Esparza",140.7),
                (2,1523648,"2019-12-02","Saturnino Rustrián","San José","Cañas – La Cruz",120.4),
                (8,1523648,"2019-12-08","Saturnino Rustrián","San José","San José – Pérez Zeledón",150.4),
                (1,1565250,"2019-12-01","Oliveiro Cárdenas","San José","Pavas – Cañas",160.5),
                (10,1565250,"2019-12-10","Oliveiro Cárdenas","San José","Circuito Presidente",100.8),
                (7,1657549,"2019-12-07","José Bonilla","San José","Guápiles – Goicoechea",80.1),
                (10,1657549,"2019-12-10","José Bonilla","San José","Circuito Presidente",100.8),
                (9,1879925,"2019-12-09","Andrián Víquez","San José","Pérez Zeledón – Llano Grande",120.2),
                (10,1879925,"2019-12-10","Andrián Víquez","San José","Circuito Presidente",100.8),
                (4,2027426,"2019-12-04","Andrey Amador","Heredia","Nicoya – Esparza",140.7),
                (8,2027426,"2019-12-08","Andrey Amador","Heredia","San José – Pérez Zeledón",150.4),
                (5,2324437,"2019-12-05","Antonio Agudelo","Heredia","Esparza – Grecia",120.8),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])
    
    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = sum
    col_oper = "kilometros"
    alias = "ciclista_kmt"
    sort= desc
    col_filter = "provincia"
    filter = "San José"
    myTop = 3
    
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, myTop)

    data_agregado = ([
                        ('Germán Loaiza', 402.00),
                        ('Saturnino Rustrián', 270.80),
                        ('Joseph Chavarria', 261.30),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'ciclista_kmt'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 20
# ---------------------------------------------------------------------------------------------
def test_topn_ciclistas_provincia_promedio_top3(spark_session):
    
    data =  ([
                (1,1160892,"2019-12-01","Joseph Chavarria","San José","Pavas – Cañas",160.5),
                (6,1160892,"2019-12-06","Joseph Chavarria","San José","Paraíso – Paraíso",100.8),
                (2,1346775,"2019-12-02","Luis Morera","Cartago","Cañas – La Cruz",120.4),
                (4,1346775,"2019-12-04","Luis Morera","Cartago","Nicoya – Esparza",140.7),
                (10,1346775,"2019-12-10","Luis Morera","Cartago","Circuito Presidente",100.8),
                (1,1403104,"2019-12-01","Germán Loaiza","San José","Pavas – Cañas",160.5),
                (4,1403104,"2019-12-04","Germán Loaiza","San José","Nicoya – Esparza",140.7),
                (6,1403104,"2019-12-06","Germán Loaiza","San José","Paraíso – Paraíso",100.8),
                (2,1467497,"2019-12-02","Luis Espinoza","San José","Cañas – La Cruz",120.4),
                (4,1467497,"2019-12-04","Luis Espinoza","San José","Nicoya – Esparza",140.7),
                (2,1523648,"2019-12-02","Saturnino Rustrián","San José","Cañas – La Cruz",120.4),
                (8,1523648,"2019-12-08","Saturnino Rustrián","San José","San José – Pérez Zeledón",150.4),
                (1,1565250,"2019-12-01","Oliveiro Cárdenas","San José","Pavas – Cañas",160.5),
                (10,1565250,"2019-12-10","Oliveiro Cárdenas","San José","Circuito Presidente",100.8),
                (7,1657549,"2019-12-07","José Bonilla","San José","Guápiles – Goicoechea",80.1),
                (10,1657549,"2019-12-10","José Bonilla","San José","Circuito Presidente",100.8),
                (9,1879925,"2019-12-09","Andrián Víquez","San José","Pérez Zeledón – Llano Grande",120.2),
                (10,1879925,"2019-12-10","Andrián Víquez","San José","Circuito Presidente",100.8),
                (4,2027426,"2019-12-04","Andrey Amador","Heredia","Nicoya – Esparza",140.7),
                (8,2027426,"2019-12-08","Andrey Amador","Heredia","San José – Pérez Zeledón",150.4),
                (5,2324437,"2019-12-05","Antonio Agudelo","Heredia","Esparza – Grecia",120.8),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])
    
    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = avg
    col_oper = "kilometros"
    alias = "ciclista_kmp"
    sort= desc
    col_filter = "provincia"
    filter = "San José"
    myTop = 3
    
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, myTop)

    data_agregado = ([
                        ('Saturnino Rustrián', 135.40),
                        ('Germán Loaiza', 134.00),
                        ('Joseph Chavarria', 130.65),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'ciclista_kmp'])
    
    assert actual_ds.collect() == expected_ds.collect()

# Test 21
# ---------------------------------------------------------------------------------------------
def test_topn_ciclistas_provincia_total_top5(spark_session):
    
    data =  ([
                (1,1160892,"2019-12-01","Joseph Chavarria","San José","Pavas – Cañas",160.5),
                (6,1160892,"2019-12-06","Joseph Chavarria","San José","Paraíso – Paraíso",100.8),
                (2,1346775,"2019-12-02","Luis Morera","Cartago","Cañas – La Cruz",120.4),
                (4,1346775,"2019-12-04","Luis Morera","Cartago","Nicoya – Esparza",140.7),
                (10,1346775,"2019-12-10","Luis Morera","Cartago","Circuito Presidente",100.8),
                (1,1403104,"2019-12-01","Germán Loaiza","San José","Pavas – Cañas",160.5),
                (4,1403104,"2019-12-04","Germán Loaiza","San José","Nicoya – Esparza",140.7),
                (6,1403104,"2019-12-06","Germán Loaiza","San José","Paraíso – Paraíso",100.8),
                (2,1467497,"2019-12-02","Luis Espinoza","San José","Cañas – La Cruz",120.4),
                (4,1467497,"2019-12-04","Luis Espinoza","San José","Nicoya – Esparza",140.7),
                (2,1523648,"2019-12-02","Saturnino Rustrián","San José","Cañas – La Cruz",120.4),
                (8,1523648,"2019-12-08","Saturnino Rustrián","San José","San José – Pérez Zeledón",150.4),
                (1,1565250,"2019-12-01","Oliveiro Cárdenas","San José","Pavas – Cañas",160.5),
                (10,1565250,"2019-12-10","Oliveiro Cárdenas","San José","Circuito Presidente",100.8),
                (7,1657549,"2019-12-07","José Bonilla","San José","Guápiles – Goicoechea",80.1),
                (10,1657549,"2019-12-10","José Bonilla","San José","Circuito Presidente",100.8),
                (9,1879925,"2019-12-09","Andrián Víquez","San José","Pérez Zeledón – Llano Grande",120.2),
                (10,1879925,"2019-12-10","Andrián Víquez","San José","Circuito Presidente",100.8),
                (4,2027426,"2019-12-04","Andrey Amador","Heredia","Nicoya – Esparza",140.7),
                (8,2027426,"2019-12-08","Andrey Amador","Heredia","San José – Pérez Zeledón",150.4),
                (5,2324437,"2019-12-05","Antonio Agudelo","Heredia","Esparza – Grecia",120.8),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])
    
    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = sum
    col_oper = "kilometros"
    alias = "ciclista_kmt"
    sort= desc
    col_filter = "provincia"
    filter = "San José"
    myTop = 5
    
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, myTop)

    data_agregado = ([
                        ('Germán Loaiza', 402.00),
                        ('Saturnino Rustrián', 270.80),
                        ('Joseph Chavarria', 261.30),
                        ('Oliveiro Cárdenas', 261.30),
                        ('Luis Espinoza', 261.10),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'ciclista_kmt'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 22
# ---------------------------------------------------------------------------------------------
def test_topn_ciclistas_provincia_promedio_top5(spark_session):
    
    data =  ([
                (1,1160892,"2019-12-01","Joseph Chavarria","San José","Pavas – Cañas",160.5),
                (6,1160892,"2019-12-06","Joseph Chavarria","San José","Paraíso – Paraíso",100.8),
                (2,1346775,"2019-12-02","Luis Morera","Cartago","Cañas – La Cruz",120.4),
                (4,1346775,"2019-12-04","Luis Morera","Cartago","Nicoya – Esparza",140.7),
                (10,1346775,"2019-12-10","Luis Morera","Cartago","Circuito Presidente",100.8),
                (1,1403104,"2019-12-01","Germán Loaiza","San José","Pavas – Cañas",160.5),
                (4,1403104,"2019-12-04","Germán Loaiza","San José","Nicoya – Esparza",140.7),
                (6,1403104,"2019-12-06","Germán Loaiza","San José","Paraíso – Paraíso",100.8),
                (2,1467497,"2019-12-02","Luis Espinoza","San José","Cañas – La Cruz",120.4),
                (4,1467497,"2019-12-04","Luis Espinoza","San José","Nicoya – Esparza",140.7),
                (2,1523648,"2019-12-02","Saturnino Rustrián","San José","Cañas – La Cruz",120.4),
                (8,1523648,"2019-12-08","Saturnino Rustrián","San José","San José – Pérez Zeledón",150.4),
                (1,1565250,"2019-12-01","Oliveiro Cárdenas","San José","Pavas – Cañas",160.5),
                (10,1565250,"2019-12-10","Oliveiro Cárdenas","San José","Circuito Presidente",100.8),
                (7,1657549,"2019-12-07","José Bonilla","San José","Guápiles – Goicoechea",80.1),
                (10,1657549,"2019-12-10","José Bonilla","San José","Circuito Presidente",100.8),
                (9,1879925,"2019-12-09","Andrián Víquez","San José","Pérez Zeledón – Llano Grande",120.2),
                (10,1879925,"2019-12-10","Andrián Víquez","San José","Circuito Presidente",100.8),
                (4,2027426,"2019-12-04","Andrey Amador","Heredia","Nicoya – Esparza",140.7),
                (8,2027426,"2019-12-08","Andrey Amador","Heredia","San José – Pérez Zeledón",150.4),
                (5,2324437,"2019-12-05","Antonio Agudelo","Heredia","Esparza – Grecia",120.8),
            ])

    df_data = spark_session.createDataFrame(data, 
                    ['ruta_id', 'ciclista_id', 'fecha', 'nombre_ciclista', 'provincia', 'nombre_ruta', 'kilometros'])
    
    dataFrame = df_data
    col_group = "nombre_ciclista"
    operacion = avg
    col_oper = "kilometros"
    alias = "ciclista_kmp"
    sort= desc
    col_filter = "provincia"
    filter = "San José"
    myTop = 5
    
    actual_ds =  aggregater_filter(dataFrame, col_group, operacion, col_oper, alias, sort, col_filter, filter, myTop)

    data_agregado = ([
                        ('Saturnino Rustrián', 135.40),
                        ('Germán Loaiza', 134.00),
                        ('Joseph Chavarria', 130.65),
                        ('Oliveiro Cárdenas', 130.65),
                        ('Luis Espinoza', 130.55),
                    ])

    expected_ds = spark_session.createDataFrame(data_agregado, 
                    ['nombre_ciclista', 'ciclista_kmp'])
    
    assert actual_ds.collect() == expected_ds.collect()
