#!/bin/bash
docker build --tag ciclismo .
