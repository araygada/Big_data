#! /bin/bash
spark-submit aggregate.py
