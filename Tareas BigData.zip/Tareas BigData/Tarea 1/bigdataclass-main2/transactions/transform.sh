#!/bin/bash
spark-submit transform.py
