#! /bin/bash
spark-submit join.py
