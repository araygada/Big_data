#! /bin/bash
spark-submit read.py
