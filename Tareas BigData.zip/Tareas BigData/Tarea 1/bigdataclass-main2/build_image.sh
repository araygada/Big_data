#!/bin/bash
docker build --tag bigdata .
