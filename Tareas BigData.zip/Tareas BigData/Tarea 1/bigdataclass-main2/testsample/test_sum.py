def test_sum_two_correctly():
    assert 2 + 2 == 4


def test_sum_two_incorrectly():
    # Expected to fail. Replace by
    # assert 3 + 3 == 6
    assert 3 + 3 == 5
