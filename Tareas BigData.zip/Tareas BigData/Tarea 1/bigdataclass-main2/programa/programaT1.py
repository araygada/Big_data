from datetime import datetime

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, date_format, udf
from pyspark.sql.types import (DateType, IntegerType, FloatType, StructField,
                               StructType, TimestampType, StringType)


spark = SparkSession.builder.appName("Ciclismo").getOrCreate()


print("\n")
print("=" * 87)
print("Este programa se basa en informacion sobre 44 ciclistas y permite establecer ")
print("el top n de los resultados de los deportistas tanto en kilometros totales ")
print("como en promedio de kilometros diarios \n")


mensaje = "Indique un numero entre 1 y 44 para determinar la clasificacion top correspondiente:"

def nTop(message):

    ans = 0
    while not ans:
        try:
            ans = int(input(message))
            if ans < 1 or ans > 44:
                raise ValueError
        except ValueError:
            ans = 0
            print("Esa no es una opcion valida!")
    return ans


#myTop = nTop(mensaje)

#print(f"El numero de top es: {myTop}")

# Carga del csv de ciclistas
# ---------------------------------------------------------------------------------------------------
schema_ciclista = StructType([StructField('id', IntegerType()),
                        StructField('nombre', StringType()),
                        StructField('provincia', StringType()),
                        ])

df_ciclistas = spark.read.csv("ciclista.csv",
                            schema=schema_ciclista,
                            header=False)
df_ciclistas.show()

# Carga del csv de rutas
# ---------------------------------------------------------------------------------------------------
schema_ruta = StructType([StructField('id', IntegerType()),
                        StructField('nombre', StringType()),
                        StructField('kilometros', FloatType()),
                        ])

df_rutas = spark.read.csv("ruta.csv",
                        schema=schema_ruta,
                        header=False)
df_rutas.show()

# Carga del csv de actividades
# ---------------------------------------------------------------------------------------------------
schema_actividades = StructType([StructField('id_ruta', IntegerType()),
                        StructField('id_ciclista', IntegerType()),
                        StructField('fecha', TimestampType()),
                        ])

df_actividades = spark.read.csv("actividad.csv",
                                schema=schema_actividades,
                                header=True)
df_actividades.show()

# Incluir una nueva columna con el formateo de la fecha original
formatted_df = df_actividades.withColumn("date_string",
                                    date_format(col("fecha"),'yyyy/MM/dd'))
formatted_df.show()

# Create a user defined function
#string_to_date = \
#    udf(lambda text_date: datetime.strptime(text_date, '%m/%d/%Y'),
#        DateType())

#typed_df = formatted_df.withColumn("date", string_to_date(formatted_df.date_string))
#typed_df.show()
#typed_df.printSchema()
