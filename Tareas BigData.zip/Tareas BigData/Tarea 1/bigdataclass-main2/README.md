# Instituto Tecnológico de Costa Rica
## Programa de Ciencia de los Datos - Módulo Big Data
El repositorio actual contiene recursos para el uso de los estudiantes como
parte del módulo de Big Data, únicamente, o como material de referencia para
actividades sin fines de lucro.

Los derechos de autoría corresponden al Instituto Tecnológico de Costa Rica
y debe darse crédito en cualquier tipo de uso, fuera de los programas
impartidos por el Instituto

# Costa Rica Institute of Technology
# Data Science Program - Big Data Class
This repository contains resources inteded to be used by students taking the
Big Data class, only, or as reference material for not for profit activities.

Copyright belongs to Costa Rica Institute of Technology and appropriate
citations are expected for any type of usage, outside of the programs managed
by the Institute.
