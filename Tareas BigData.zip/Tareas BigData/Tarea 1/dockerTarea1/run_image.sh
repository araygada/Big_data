#!/bin/bash
docker run -p 8888:8888 -i -t tarea1 /bin/bash
