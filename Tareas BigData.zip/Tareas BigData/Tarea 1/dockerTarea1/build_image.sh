#!/bin/bash
docker build --tag tarea1 .
