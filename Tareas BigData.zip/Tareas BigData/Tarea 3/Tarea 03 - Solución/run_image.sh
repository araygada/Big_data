#!/bin/bash
docker run -p 8888:8888 -i -t tarea_3 /bin/bash
