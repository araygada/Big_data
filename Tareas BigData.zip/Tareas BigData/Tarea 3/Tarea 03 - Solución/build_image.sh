#!/bin/bash
docker build --tag tarea_3 .
