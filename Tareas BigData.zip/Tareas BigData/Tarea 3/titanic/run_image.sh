#!/bin/bash
docker run -p 8888:8888 -i -t titanic /bin/bash
