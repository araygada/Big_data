#!/bin/bash
docker build --tag titanic .
