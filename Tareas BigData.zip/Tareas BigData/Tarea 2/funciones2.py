# Este archivo contiene las funciones a utilizar en la Tarea01 sobre ciclismo
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, date_format, udf, sum, count, avg, mean, desc, round
from pyspark.sql import Window
from pyspark.sql.types import (DateType, IntegerType, FloatType, StructField,
                               StructType, TimestampType, StringType)

# spark = SparkSession.builder.appName("Funciones").getOrCreate()

def joiner(dataFrame1, dataFrame2, columna, tipo):
    # Unión de dataFrame1 y data Frame2 en relación con la columna indicada
    # tipo => Tipo de unión (p.e. inner, right, left)
    df_joined = dataFrame1.join(dataFrame2, on=columna, how=tipo)

    return df_joined


def aggregater(dataFrame, col_group, operacion, col_oper, alias, sort):
    # DataFrame intermedio de agregación por kilómetros totales o promedio
    # col_group => columna para el groupBy
    # col_oper   => columna a operar
    # operacion  => tipo de operación a aplicar (p.e sum, avg)
    # sort       => tipo de ordenamiento (p.e. desc)
    df_aggregated = dataFrame.groupBy(col_group) \
                    .agg(round(operacion(col_oper),2).alias(alias)) \
                    .sort(sort(alias))

    return df_aggregated

def aggregater_top(dataFrame, col_group, operacion, col_oper, alias, sort, nTop):
    # DataFrame intermedio de agregación por kilómetros totales o promedio
    # col_group  => columna para el groupBy
    # col_oper   => columna a operar
    # operacion  => tipo de operación a aplicar (p.e sum, avg)
    # sort       => tipo de ordenamiento (p.e. desc)
    # col_filter => columna a filtrar
    # filter     => Elemento a filtrar
    # nTop       => Número del top que se quiere mostrar (p.e. top 2)

    df_aggregated = dataFrame.groupBy(col_group) \
                    .agg(round(operacion(col_oper),2).alias(alias)) \
                    .sort(sort(alias))
                    
    df_ranked = df_aggregated.limit(nTop)
    
    return df_ranked
