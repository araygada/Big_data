# Bibliotecas

from pyspark.sql.functions import col, round, when, lit
import pyspark.sql.functions as F




#----------------------------Total de viajes por código postal-----------------------------

def calc_total_viajes(df, remove_null):
        """
        Calcula el total de viajes por código postal, indica si este es origen o destino y
         la cantidad de viajes para ese código, tanto como origen y como destino. 

        df: dataframe con columnas Codigo_postal_origen y Codigo postal_destino.

        remove_null: Si es verdadero, las filas con valores nulos son eliminadas. 
        Si es falso, se conservan las filas con valores nulos y estos se renombran a "Desconocido".     
        """

        if remove_null == True:

                df = df.na.drop()

                                
                codigo_origen = df.groupBy("Codigo_postal_origen").count().\
                        withColumn("Tipo_codigo", (lit("Origen"))).\
                        withColumn("Cantidad_viajes", col("count")).\
                                selectExpr("Codigo_postal_origen as Codigo_postal", "Tipo_codigo", "Cantidad_viajes")  


                codigo_destino = df.groupBy("Codigo_postal_destino").count().\
                        withColumn("Tipo_codigo", (lit("Destino"))).\
                        withColumn("Cantidad_viajes", col("count")).\
                                selectExpr("Codigo_postal_destino as Codigo_postal", "Tipo_codigo", "Cantidad_viajes")


        else: 
                df = df.withColumn("Codigo_postal_origen", when(col("Codigo_postal_origen").isNull(), "Desconocido").\
                        otherwise(col("Codigo_postal_origen"))).\
                        withColumn("Codigo_postal_destino", when(col("Codigo_postal_destino").isNull(), "Desconocido").\
                                otherwise(col("Codigo_postal_destino")))

                
                codigo_origen = df.groupBy("Codigo_postal_origen").count().\
                        withColumn("Tipo_codigo", when(col("Codigo_postal_origen") == "Desconocido", "Desconocido").\
                                otherwise(lit("Origen"))).\
                        withColumn("Cantidad_viajes", col("count")).\
                                selectExpr("Codigo_postal_origen as Codigo_postal", "Tipo_codigo", "Cantidad_viajes")  


                codigo_destino = df.groupBy("Codigo_postal_destino").count().\
                        withColumn("Tipo_codigo", when(col("Codigo_postal_destino") == "Desconocido", "Desconocido").\
                                otherwise(lit("Destino"))).\
                        withColumn("Cantidad_viajes", col("count")).\
                                selectExpr("Codigo_postal_destino as Codigo_postal", "Tipo_codigo", "Cantidad_viajes") 


        df2 = codigo_origen.union(codigo_destino).sort(col("Cantidad_viajes").desc())


        return df2


#---------------------------------Cálculo de ingresos por viaje------------------------------------------------

def ingresos(df):

        """
        Calcula los ingresos, multiplicando los kilómetros por el precio del kilómetro para cada viaje.
        Elimina las filas en que la columna Kilometros y/o Precio_kilometro son nulas. 
        Retorna un dataframe con las columnas originales y una columna con el ingreso para cada viaje. 
        
        df: dataframe con columnas Identificador, Codigo_postal_origen, Codigo postal_destino, Kilometros y Precio_kilometro.  
        """

        
        if df.filter("Kilometros is NULL") or df.filter("Precio_kilometro is NULL"):   
                
                df = df.na.drop(subset=["Precio_kilometro", "Kilometros"])
                
                df_ing = df.withColumn("Ingresos", round(df["Precio_kilometro"] * df["Kilometros"], 2))

        else:

                df_ing = df.withColumn("Ingresos", round(df["Precio_kilometro"] * df["Kilometros"], 2))

        
        return df_ing 

#-----------------------------------Total de ingresos por código postal---------------------------

def calc_total_ingresos(df, remove_null):
        
        """
        Calcula el total de ingresos por código postal, indica si este es origen o destino y
         la cantidad de ingresos para ese código, tanto como origen y como destino. 

        df: dataframe con columnas Identificador, Codigo_postal_origen, Codigo postal_destino, Kilometros y Precio_kilometro.

        remove_null: Si es verdadero, las filas con valores nulos son eliminadas. 
        Si es falso, se conservan las filas con valores nulos y estos se renombran a "Desconocido".     
        """

        if remove_null == True: 

                df = df.na.drop()

                df_ing = ingresos(df) 

                codigo_origen = df_ing.groupBy("Codigo_postal_origen").sum("Ingresos").\
                        withColumn("Total_Ingresos", col("sum(Ingresos)")).\
                        withColumn("Tipo_codigo", lit("Origen")).sort(col("Total_Ingresos").desc()).\
                        selectExpr("Codigo_postal_origen as Codigo_postal", "Tipo_codigo", "Total_Ingresos")  

                codigo_destino = df_ing.groupBy("Codigo_postal_destino").sum("Ingresos").\
                        withColumn("Total_Ingresos", col("sum(Ingresos)")).\
                        withColumn("Tipo_codigo", lit("Destino")).sort(col("Total_Ingresos").desc()).\
                        selectExpr("Codigo_postal_destino as Codigo_postal", "Tipo_codigo", "Total_Ingresos") 

        else:

                df = df.withColumn("Codigo_postal_origen", when(col("Codigo_postal_origen").isNull(), "Desconocido").\
                        otherwise(col("Codigo_postal_origen"))).\
                        withColumn("Codigo_postal_destino", when(col("Codigo_postal_destino").isNull(), "Desconocido").\
                                otherwise(col("Codigo_postal_destino")))

                df_ing = ingresos(df)

                
                codigo_origen = df_ing.groupBy("Codigo_postal_origen").sum("Ingresos").\
                        withColumn("Total_Ingresos", col("sum(Ingresos)")).\
                        withColumn("Tipo_codigo", when(col("Codigo_postal_origen") == "Desconocido", "Desconocido").\
                                otherwise(lit("Origen"))).sort(col("Total_Ingresos").desc()).\
                        selectExpr("Codigo_postal_origen as Codigo_postal", "Tipo_codigo", "Total_Ingresos")  


                codigo_destino = df_ing.groupBy("Codigo_postal_destino").sum("Ingresos").\
                        withColumn("Total_Ingresos", col("sum(Ingresos)")).\
                        withColumn("Tipo_codigo", when(col("Codigo_postal_destino") == "Desconocido", "Desconocido").\
                                otherwise(lit("Destino"))).sort(col("Total_Ingresos").desc()).\
                        selectExpr("Codigo_postal_destino as Codigo_postal", "Tipo_codigo", "Total_Ingresos") 



        df2 = codigo_origen.union(codigo_destino).sort(col("Total_Ingresos").desc())


        return df2



#-------------------------------------------------------Métricas-----------------------------------------------------

# Métrica 1: Persona con más kilómetros


def metrica_1(df):
        """
        Selecciona el identificador de la persona con más kilómetros recorridos y retorna un dataframe con las columnas "Tipo_metrica" y "Valor".
        Si existe un empate por el primer lugar, la función retorna los n identificadores de las personas con más kilómetros recorridos.

        df = Dataframe con columnas Identificador, Codigo_postal_origen, Codigo postal_destino, Kilometros y Precio_kilometro.        
        """        

        if df.filter("Kilometros is NULL") or df.filter("Identificador is NULL"): 

                df = df.na.drop(subset=["Kilometros", "Identificador"])

               

        df1 = df.groupBy("Identificador").sum("Kilometros").withColumn("Tipo_Metrica", lit("persona_con_mas_km")).\
                withColumn("Total_Kilometros", col("sum(Kilometros)")).withColumn("Valor", col("Identificador")).\
                sort(col("Total_Kilometros").desc()).select("Tipo_Metrica", "Valor", "Total_Kilometros")                

        max_kms = df1.agg({"Total_Kilometros":"max"})

       

        max_kms = max_kms.collect()[0]["max(Total_Kilometros)"]
        

        df1 = df1.withColumn("max_kms", lit(max_kms))

        df1 = df1.filter("Total_Kilometros == max_kms")

        cantidad = df1.count()

                
        if cantidad > 1: # Si se da un empate por el primer lugar y hay más de una persona con la misma cantidad de kilómetros 
                        # recorridos se elige la cantidad de filas correspondientes, de no ser así, solo se escoge la primera fila.

              
                df1 = df.groupBy("Identificador").sum("Kilometros").withColumn("Tipo_Metrica", lit("persona_con_mas_km")).\
                withColumn("Total_Kilometros", col("sum(Kilometros)")).withColumn("Valor", col("Identificador")).\
                sort(col("Total_Kilometros").desc()).select("Tipo_Metrica", "Valor").limit(cantidad)

                        
        else: 
                

                df1 = df.groupBy("Identificador").sum("Kilometros").withColumn("Tipo_Metrica", lit("persona_con_mas_km")).\
                        withColumn("Total_Kilometros", col("sum(Kilometros)")).withColumn("Valor", col("Identificador")).\
                         sort(col("Total_Kilometros").desc()).select("Tipo_Metrica", "Valor").limit(1)        


        return df1



# Métrica 2: Persona con más ingresos


def metrica_2(df): 

        """
        Selecciona el identificador de la persona con más ingresos y retorna un dataframe con las columnas "Tipo_metrica" y "Valor".
        Si existe un empate por el primer lugar, la función retorna los n identificadores de las personas con más ingresos.
        Elimina las filas en las que Kilometros, Precio_kilometro y/o Identificador son nulos. 

        df = Dataframe con columnas Identificador, Codigo_postal_origen, Codigo postal_destino, Kilometros y Precio_kilometro.        
        """

        if df.filter("Kilometros is NULL") or df.filter("Precio_kilometro") or df.filter("Identificador is NULL"): 

                df = df.na.drop(subset=["Kilometros", "Precio_kilometro", "Identificador"])
 
        df_ing = ingresos(df)

        
        df2 = df_ing.groupBy("Identificador").sum("Ingresos").withColumn("Total_Ingresos", col("sum(Ingresos)")).\
                withColumn("Tipo_Metrica", lit("persona_con_mas_ingresos")).withColumn("Valor", col("Identificador")).\
                sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor", "Total_Ingresos")

        max_ing = df2.agg({"Total_Ingresos":"max"})

        max_ing = max_ing.collect()[0]["max(Total_Ingresos)"]
       

        df2 = df2.withColumn("max_ing", lit(max_ing))

        df2 = df2.filter("Total_Ingresos == max_ing")

        cantidad = df2.count()
     

        if cantidad > 1: # Si se da un empate por el primer lugar y hay más de una persona con la misma cantidad de ingresos.
                        # recorridos se elige la cantidad de filas correspondientes, de no ser así, solo se escoge la primera fila.

                
                df2 = df_ing.groupBy("Identificador").sum("Ingresos").withColumn("Tipo_Metrica", lit("persona_con_mas_ingresos")).\
                withColumn("Total_Ingresos", col("sum(Ingresos)")).withColumn("Valor", col("Identificador")).\
                sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor").limit(cantidad)

                        
        else: 
                
                df2 = df_ing.groupBy("Identificador").sum("Ingresos").withColumn("Tipo_Metrica", lit("persona_con_mas_ingresos")).\
                withColumn("Total_Ingresos", col("sum(Ingresos)")).withColumn("Valor", col("Identificador")).\
                sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor").limit(1)       


        return df2




# Métricas 3, 4 y 5: percentil_25, percentil_50, percentil_75

def metrica_3(df, spark_session):

        """
        Retorna los percentiles 25, 50 y 75 del total de ingresos de los conductores. 
        
        df: Dataframe con columnas Identificador, Codigo_postal_origen, Codigo postal_destino, Kilometros y Precio_kilometro.  
        spark_session: Sesión de spark en la cual se crea un dataframe con los percentiles y con las columnas 'Tipo_Metrica' y 'Valor'.

        """



        df_ing = ingresos(df)

             
        df = df_ing.groupBy("Identificador").sum("Ingresos").withColumn("Total_Ingresos", col("sum(Ingresos)")).\
                sort(col("Total_Ingresos").asc())


        p25 = df.approxQuantile("Total_Ingresos", [0.25], 0)

        p50 = df.approxQuantile("Total_Ingresos", [0.50], 0)

        p75 = df.approxQuantile("Total_Ingresos", [0.75], 0)

        data345 = [("percentil_25", p25[0]), 
                ("percentil_50", p50[0]),
                ("percentil_75", p75[0]),]

        df3 = spark_session.createDataFrame(data345, ["Tipo_Metrica", "Valor"])

        return df3


# Métrica 6: Código postal origen con más ingresos

def metrica_6(df):

        """
        Selecciona el código postal de origen con más ingresos y retorna un dataframe con las columnas "Tipo_metrica" y "Valor".
        Si existe un empate por el primer lugar, la función retorna los n códigos postales de origen con más ingresos.
        Elimina las filas en las que Kilometros, Precio_kilometro y/o Codigo_postal_origen son nulos. 

        df = Dataframe con columnas Identificador, Codigo_postal_origen, Codigo postal_destino, Kilometros y Precio_kilometro.        
        """


        if df.filter("Kilometros is NULL") or df.filter("Precio_kilometro") or df.filter("Codigo_postal_origen"): 

                df = df.na.drop(subset=["Kilometros", "Precio_kilometro", "Codigo_postal_origen"])  
        
        df_ing = ingresos(df) 

          

        df6 = df_ing.groupBy("Codigo_postal_origen").sum("Ingresos").withColumn("Total_Ingresos", col("sum(Ingresos)")).\
            withColumn("Tipo_Metrica", lit("codigo_postal_origen_con_mas_ingresos")).withColumn("Valor", col("Codigo_postal_origen")).\
            sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor", "Total_Ingresos")

        max_ing = df6.agg({"Total_Ingresos":"max"})

        max_ing = max_ing.collect()[0]["max(Total_Ingresos)"]
       

        df6 = df6.withColumn("max_ing", lit(max_ing))

        df6 = df6.filter("Total_Ingresos == max_ing")

        cantidad = df6.count()
     

        if cantidad > 1: # Si se da un empate por el primer lugar y hay más de un código postal de origen con la misma cantidad de ingresos.
                        # recorridos se elige la cantidad de filas correspondientes, de no ser así, solo se escoge la primera fila.

                 df6 = df_ing.groupBy("Codigo_postal_origen").sum("Ingresos").withColumn("Tipo_Metrica", lit("codigo_postal_origen_con_mas_ingresos")).\
                withColumn("Total_Ingresos", col("sum(Ingresos)")).withColumn("Valor", col("Codigo_postal_origen")).\
                sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor").limit(cantidad)

                        
        else: 
                
                df6 = df_ing.groupBy("Codigo_postal_origen").sum("Ingresos").withColumn("Tipo_Metrica", lit("codigo_postal_origen_con_mas_ingresos")).\
                withColumn("Total_Ingresos", col("sum(Ingresos)")).withColumn("Valor", col("Codigo_postal_origen")).\
                sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor").limit(1)


        return df6



# Métrica 7: Código postal destino con más ingresos


def metrica_7(df): 

        """
        Selecciona el código postal de destino con más ingresos y retorna un dataframe con las columnas "Tipo_metrica" y "Valor".
        Si existe un empate por el primer lugar, la función retorna los n códigos postales de destino con más ingresos.
        Elimina las filas en las que Kilometros, Precio_kilometro y/o Codigo_postal_destino son nulos. 

        df = Dataframe con columnas Identificador, Codigo_postal_destino, Codigo postal_destino, Kilometros y Precio_kilometro.        
        """


        if df.filter("Kilometros is NULL") or df.filter("Precio_kilometro") or df.filter("Codigo_postal_destino"): 

                df = df.na.drop(subset=["Kilometros", "Precio_kilometro", "Codigo_postal_destino"])  

                        
        df_ing = ingresos(df) 

          

        df7 = df_ing.groupBy("Codigo_postal_destino").sum("Ingresos").withColumn("Total_Ingresos", col("sum(Ingresos)")).\
            withColumn("Tipo_Metrica", lit("codigo_postal_destino_con_mas_ingresos")).withColumn("Valor", col("Codigo_postal_destino")).\
            sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor", "Total_Ingresos")

        max_ing = df7.agg({"Total_Ingresos":"max"})

        max_ing = max_ing.collect()[0]["max(Total_Ingresos)"]
       

        df7 = df7.withColumn("max_ing", lit(max_ing))

        df7 = df7.filter("Total_Ingresos == max_ing")

        cantidad = df7.count()
     

        if cantidad > 1: # Si se da un empate por el primer lugar y hay más de un código postal de destino con la misma cantidad de ingresos.
                        # recorridos se elige la cantidad de filas correspondientes, de no ser así, solo se escoge la primera fila.

                 df7 = df_ing.groupBy("Codigo_postal_destino").sum("Ingresos").withColumn("Tipo_Metrica", lit("codigo_postal_destino_con_mas_ingresos")).\
                withColumn("Total_Ingresos", col("sum(Ingresos)")).withColumn("Valor", col("Codigo_postal_destino")).\
                sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor").limit(cantidad)

                        
        else: 
                
                df7 = df_ing.groupBy("Codigo_postal_destino").sum("Ingresos").withColumn("Tipo_Metrica", lit("codigo_postal_destino_con_mas_ingresos")).\
                withColumn("Total_Ingresos", col("sum(Ingresos)")).withColumn("Valor", col("Codigo_postal_destino")).\
                sort(col("Total_Ingresos").desc()).select("Tipo_Metrica", "Valor").limit(1)


        return df7


#----------------------------------------------------------Métricas unificadas--------------------------------------------

def todas_metricas(df, spark_session):

        """
        Llama a todas las funciones de métricas y concatena las filas para retornar un dataframe 
        con todos los tipos de métricas y valores correspondientes. 
        
        df: Dataframe con columnas Identificador, Codigo_postal_origen, Codigo postal_destino, Kilometros y Precio_kilometro.  
        spark_session: Sesión de spark en la cual se crea un dataframe con los percentiles y con las columnas 'Tipo_Metrica' y 'Valor'.

        """       

        df1 = metrica_1(df)

        df2 = metrica_2(df)

        df3 = metrica_3(df, spark_session)

        df6 = metrica_6(df)

        df7 = metrica_7(df)
        

        df_union = df1.union(df2).union(df3).union(df6).union(df7)

        return df_union



#-----------------------------------------Creación de csv de los dataframes----------------------

def crear_csvs(table, file_name, path):

        """
        Genera un archivo csv a partir de un dataframe o tabla en memoria con codificación utf-8 y lo guarda en 
        el directorio con el nombre de archivo indicado. 
        
        table: dataframe con columnas nombradas que se desea guardar como csv.
        file_name: nombre de archivo para el csv.
        path: directorio para guardar el archivo csv.
        
        """
        
        table.coalesce(1).write.mode('overwrite').option('encoding', 'utf-8').csv('{}/{}.csv'.format(path, file_name), header=True)
