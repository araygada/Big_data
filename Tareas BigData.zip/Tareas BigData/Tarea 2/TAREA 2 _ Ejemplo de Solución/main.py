# Bibliotecas

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, col, explode
from funciones import calc_total_viajes, calc_total_ingresos, metrica_1, metrica_2, metrica_3, metrica_6, metrica_7, todas_metricas, crear_csvs



# Iniciar sesión de Spark 

spark = SparkSession.builder.appName("Tarea2").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")



# Input a leer

input_1 = sys.argv[1]



# Creación del dataframe a partir de los archivos json


df = spark.read.option("multiline","true").json(input_1 + "*.json").select("identificador", explode("viajes")).\
             withColumn("Identificador", col("identificador")).\
             withColumn("Codigo_postal_origen", col("col.codigo_postal_origen")).\
             withColumn("Codigo_postal_destino", col("col.codigo_postal_destino")).\
             withColumn("Kilometros", col("col.kilometros")).\
             withColumn("Precio_kilometro", col("col.precio_kilometro")).drop("col")


# Visualizar dataframe

df.show()


# Calcular total de viajes por código postal

total_viajes = calc_total_viajes(df, remove_null= False)

print("------------------------------")
print("Total de viajes por código postal")

total_viajes.show()


# Calcular total de ingresos por código postal

total_ingresos = calc_total_ingresos(df, remove_null= False)

print("------------------------------")
print("Total de ingresos por código postal")

total_ingresos.show()


# Calcular métricas

# Métrica 1

print("------------------------------")
print("Métrica 1: Persona con más kilómetros")

metricas1 = metrica_1(df)

metricas1.show()


# Métrica 2

print("------------------------------")
print("Métrica 2: Persona con más ingresos")

metricas2 = metrica_2(df)

metricas2.show()


# Métricas 3, 4, y 5

print("------------------------------")
print("Métricas 3, 4 y 5: Percentil 25, 50 y 75")

metricas3 = metrica_3(df, spark)

metricas3.show()


# Métrica 6

print("------------------------------")
print("Métrica 6: Código postal origen con más ingresos:")


metricas6 = metrica_6(df)

metricas6.show()


# Métrica 7

print("------------------------------")
print("Métrica 7: Código postal destino con más ingresos:")

metricas7 = metrica_7(df)

metricas7.show()


# Dataframe con todas las métricas

print("------------------------------")
print("Métricas")

metricas = todas_metricas(df, spark)

metricas.show()


# Generación de los csv 

# total_viajes.csv

print("------------------------------")

print("Guardando tabla total_viajes...")

crear_csvs(total_viajes, total_viajes, "Archivos_finales/Total_viajes")

print("Tabla total_viajes guardada  \n")


# total_ingresos.csv

print("Guardando tabla total_ingresos...")

crear_csvs(total_ingresos, total_ingresos, "Archivos_finales/Total_ingresos")

print("Tabla total_ingresos guardada  \n")



# metricas.csv

print("Guardando tabla metricas...")

crear_csvs(metricas, metricas, "Archivos_finales/Metricas")

print("Tabla metricas guardada  \n")