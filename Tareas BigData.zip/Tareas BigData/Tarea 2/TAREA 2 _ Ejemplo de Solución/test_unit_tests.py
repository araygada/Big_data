from funciones import calc_total_viajes, ingresos, calc_total_ingresos, metrica_1, metrica_2, metrica_3, metrica_6, metrica_7, todas_metricas
from pyspark.sql.types import (StringType, StructField, StructType, FloatType, LongType, DoubleType)

#----------------------------Tests para cálculo del total de viajes por código postal------------------------

# Unit test 1: Total_viajes datos correctos y completos


def test_total_viajes_completo(spark_session, remove_null = False):
     print("\n")
     print("Unit Test 1: Total_viajes datos correctos y completos")
     print("\n")


     dataframe = [(78268, 60402, 50802, 12.1, 1400),
                    (78268, 21303, 20103, 17.2, 1000),
                    (99256, 60402, 20103, 3.5, 800),
                    (81530, 20903, 60402, 5.4, 1200),
                    (81530, 20903, 11903,7.8, 900)] 
                    
         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     correct_dataframe_schema = StructType([StructField('Codigo_postal', StringType(), nullable = True),
                         StructField('Tipo_codigo', StringType(), nullable = False),
                         StructField('Cantidad_viajes', LongType(), nullable = False)])


     correct_data = [(60402, "Origen", 2),
                    (20903, "Origen", 2),                    
                    (20103, "Destino", 2),
                    (21303, "Origen", 1),
                    (50802, "Destino", 1),
                    (60402, "Destino", 1),
                    (11903, "Destino", 1)]


     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     total_viajes = calc_total_viajes(df, remove_null)



     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     print("\n")
     total_viajes.show()
     print("\n")
     print("-----------------------------------------------")


     assert total_viajes.collect() == correct_df.collect()


# Unit test 2: Total_viajes datos faltantes eliminados

     
def test_total_viajes_borrar_NA(spark_session, remove_null = True):
     print("\n")
     print("Unit Test 2: total_viajes borrar datos faltantes")
     print("\n")


     dataframe = [(78268, None, 50802, 12.1, 1400),
                    (78268, 21303, 20103, 17.2, 1000),
                    (99256, 60402, 20103, 3.5, 800),
                    (81530, 20903, None, 5.4, 1200),
                    (81530, None, 11903,7.8, 900)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     correct_dataframe_schema = StructType([StructField('Codigo_postal', LongType(), nullable = True),
                         StructField('Tipo_codigo', StringType(), nullable = False),
                         StructField('Cantidad_viajes', LongType(), nullable = False)])

     correct_data = [(20103, "Destino", 2),
                    (21303, "Origen", 1),
                    (60402, "Origen", 1)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     total_viajes = calc_total_viajes(df, remove_null)
       

     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     total_viajes.show()
     print("\n")
     print("-----------------------------------------------")


     assert total_viajes.collect() == correct_df.collect()


     

# Unit test 3: Total_viajes datos faltantes conservados

     
def test_total_viajes_conservar_NA(spark_session, remove_null = False):
     print("\n")
     print("Unit Test 3: Total_viajes datos faltantes conservados")
     print("\n")


     dataframe = [(78268, None, 50802, 12.1, 1400),
                    (78268, 21303, 20103, 17.2, 1000),
                    (99256, 60402, 20103, 3.5, 800),
                    (81530, 20903, None, 5.4, 1200),
                    (81530, None, 11903,7.8, 900)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     correct_dataframe_schema = StructType([StructField('Codigo_postal', StringType(), nullable = True),
                         StructField('Tipo_codigo', StringType(), nullable = False),
                         StructField('Cantidad_viajes', LongType(), nullable = False)])


     correct_data = [("Desconocido", "Desconocido", 2),
                    (20103, "Destino", 2),
                    (60402, "Origen", 1),                    
                    (21303, "Origen", 1),
                    (20903, "Origen", 1),
                    (50802, "Destino", 1),
                    (11903, "Destino", 1),
                    ("Desconocido", "Desconocido", 1)
                    ]


     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     total_viajes = calc_total_viajes(df, remove_null)

  

     print("-----------------------------------------------")
     print("Output esperado")     
     correct_df.show()

     print("Output del código")
     total_viajes.show()
     print("\n")
     print("-----------------------------------------------")


     assert total_viajes.collect() == correct_df.collect()


#----------------------------Tests para cálculo del total de ingresos por código postal------------------------


# Unit test 4: Ingresos eliminando Kilómetros y/o Precio faltantes


def test_ingresos_kms_precio_faltantes(spark_session):
     print("\n")
     print("Unit Test 4: total_ingresos eliminando Kilómetros y/o Precio faltantes")
     print("\n")


     dataframe = [(78268, 60402, 50802, None, None),
                    (78268, 21303, 20103, 17.2, 1000),
                    (99256, 60402, 20103, 3.5, None),
                    (81530, 20903, 60402, None, 1200),
                    (81530, 20903, 11903,7.8, 900)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])

    

     correct_dataframe_schema = StructType([StructField('Identificador', LongType(), nullable = True),
                                             StructField('Codigo_postal_origen', LongType(), nullable = True),
                                             StructField('Codigo_postal_destino', LongType(), nullable = True),
                                             StructField('Kilometros', DoubleType(), nullable = True),
                                             StructField('Precio_kilometro', LongType(), nullable = True),
                                             StructField('Ingresos', DoubleType(), nullable = True)])

     correct_data = [(78268, 21303, 20103, 17.2, 1000, 17200.0),
                    (81530, 20903, 11903,  7.8, 900, 7020.0)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     df_ingresos = ingresos(df) 

     

     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     df_ingresos.show()
     print("\n")
     print("-----------------------------------------------")


     assert df_ingresos.collect() == correct_df.collect()



# Unit test 5: Total_ingresos datos correctos y completos


def test_total_ingresos_completo(spark_session, remove_null = False):
     print("\n")
     print("Unit Test 5: Total_ingresos datos correctos y completos")
     print("\n")


     dataframe = [(78268, 60402, 50802, 12.1, 1400),
                    (78268, 21303, 20103, 17.2, 1000),
                    (99256, 60402, 20103, 3.5, 800),
                    (81530, 20903, 60402, 5.4, 1200),
                    (81530, 20903, 11903,7.8, 900)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     


     correct_dataframe_schema = StructType([StructField('Codigo_postal', StringType(), nullable = True),
                         StructField('Tipo_codigo', StringType(), nullable = False),
                         StructField('Total_Ingresos', FloatType(), nullable = False)])

     correct_data = [(20103, "Destino", 20000.0),
                    (60402, "Origen", 19740.0),                    
                    (21303, "Origen", 17200.0),
                    (50802, "Destino", 16940.0),
                    (20903, "Origen", 13500.0),
                    (11903, "Destino", 7020.0),
                    (60402, "Destino", 6480.0)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     total_ingresos = calc_total_ingresos(df, remove_null)


     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     total_ingresos.show()
     print("\n")
     print("-----------------------------------------------")


     assert total_ingresos.collect() == correct_df.collect()


# Unit Test 6: total_ingresos eliminando códigos postales faltantes

def test_total_ingresos_borrar_NA(spark_session, remove_null = True):
     print("\n")
     print("Unit Test 6: total_ingresos eliminando códigos postales faltantes")
     print("\n")


     dataframe = [(78268, None, 50802, 12.1, 1400),
                    (78268, 21303, 20103, 17.2, 1000),
                    (99256, 60402, 20103, 3.5, 800),
                    (81530, 20903, None, 5.4, 1200),
                    (81530, None, 11903,7.8, 900)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Codigo_postal', LongType(), nullable = True),
                         StructField('Tipo_codigo', StringType(), nullable = False),
                         StructField('Total_Ingresos', DoubleType(), nullable = False)])


     correct_data = [(20103, "Destino", 20000.0),
                    (21303, "Origen", 17200.0),
                    (60402, "Origen", 2800.0)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     total_ingresos = calc_total_ingresos(df, remove_null)


     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     total_ingresos.show()
     print("\n")
     print("-----------------------------------------------")


     assert total_ingresos.collect() == correct_df.collect()



# Unit Test 7: total_ingresos conservar datos faltantes


def test_total_ingresos_conservar_NA(spark_session, remove_null = False):
     print("\n")
     print("Unit Test 7: total_ingresos conservar datos faltantes")
     print("\n")


     dataframe = [(78268, None, 50802, 12.1, 1400),
                    (78268, 21303, 20103, 17.2, 1000),
                    (99256, 60402, 20103, 3.5, 800),
                    (81530, 20903, None, 5.4, 1200),
                    (81530, None, 11903,7.8, 900)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Codigo_postal', StringType(), nullable = True),
                         StructField('Tipo_codigo', StringType(), nullable = False),
                         StructField('Total_Ingresos', DoubleType(), nullable = False)])


     correct_data = [("Desconocido", "Desconocido", 23960.0),
                    (20103, "Destino", 20000.0),
                    (21303, "Origen", 17200.0),
                    (50802, "Destino", 16940.0),
                    (11903, "Destino", 7020.0),
                    (20903, "Origen", 6480.0),
                    ("Desconocido", "Desconocido", 6480.0),
                    (60402, "Origen", 2800.0)]


     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     total_ingresos = calc_total_ingresos(df, remove_null)

     

     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     total_ingresos.show()
     print("\n")
     print("-----------------------------------------------")


     assert total_ingresos.collect() == correct_df.collect()


#----------------------------Tests para cálculo de las métricas------------------------


# Métrica 1

# Unit Test 8: Métrica 1 Persona con más kilómetros datos completos


def test_metrica1_completo(spark_session):
     print("\n")
     print("Unit Test 8: Métrica 1 Persona con más kilómetros datos completos")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, 800),
                    (45683, 20903, 40503, 17.2, 1100),
                    (45683, 10201, 60303, 4.9, 1200),
                    (93066, 50901, 11803, 19.8, 1300),
                    (93066, 61101, 51103, 7.4, 1000),
                    (81530, 10602, 21202, 2.3, 1000),
                    (81530, 21103, 11302, 7.6, 1500),
                    (81530, 61101, 51103, 7.4, 1000)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = False)])


     correct_data = [("persona_con_mas_km", 45683)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica1 = metrica_1(df)


     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica1.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica1.collect() == correct_df.collect()


# Unit Test 9: Métrica 1 Persona con más kilómetros datos faltantes


def test_metrica1_NA(spark_session):
     print("\n")
     print("Unit Test 9: Métrica 1 Persona con más kilómetros datos faltantes")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, 800),
                    (45683, 20903, 40503, None, 1100),
                    (45683, 10201, 60303, None, 1200),
                    (93066, 50901, 11803, 19.8, 1300),
                    (None, 61101, 51103, 7.4, 1000),
                    (None, 10602, 21202, 2.3, 1000),
                    (81530, 21103, 11302, None, 1500),
                    (81530, 61101, 51103, 7.4, 1000)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = False)])


     correct_data = [("persona_con_mas_km", 93066)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica1 = metrica_1(df)


     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica1.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica1.collect() == correct_df.collect()



# Unit Test 10: Métrica 1 Persona con más kilómetros empate y datos faltantes


def test_metrica1_empate(spark_session):
     print("\n")
     print("Unit Test 10: Métrica 1 - Persona con más kilómetros empate y datos faltantes")
     print("\n")


     dataframe = [(93066, 50901, 11803, 18.1, 1300), 
               (45683, 12001, 30803, 20.5, 1300),                    
               (81530, 61101, 51103, 20.5, None),
               (None, 61102, 51104, 20.5, 1500),
               (12345, 61102, 51104, None, 1500)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = False)])


     correct_data = [("persona_con_mas_km", 81530), 
                    ("persona_con_mas_km", 45683)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica1 = metrica_1(df)


     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica1.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica1.collect() == correct_df.collect()



# Métrica 2

# Unit Test 11: Métrica 2 Persona con más ingresos datos completos


def test_metrica2_completo(spark_session):
     print("\n")
     print("Unit Test 11: Métrica 2 Persona con más ingresos datos completos")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, 800),
                    (45683, 20903, 40503, 17.2, 1100),
                    (45683, 10201, 60303, 4.9, 1200),
                    (93066, 50901, 11803, 19.8, 1300),
                    (93066, 61101, 51103, 7.4, 1000),
                    (81530, 10602, 21202, 2.3, 1000),
                    (81530, 21103, 11302, 7.6, 1500),
                    (81530, 61101, 51103, 7.4, 1000)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = False)])


     correct_data = [("persona_con_mas_ingresos", 45683)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica2 = metrica_2(df)


         
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica2.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica2.collect() == correct_df.collect()



# Unit Test 12: Métrica 2 Persona con más ingresos datos faltantes

def test_metrica2_NA(spark_session):
     print("\n")
     print("Unit Test 12: Métrica 2 Persona con más ingresos datos faltantes")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, None),
                    (45683, 20903, 40503, 17.2, None),
                    (45683, None, 60303, 4.9, 1200),
                    (None, 50901, 11803, 19.8, 1300),
                    (93066, 61101, 51103, None, 1000),
                    (81530, 10602, 21202, None, 1000),
                    (81530, 21103, 11302, 7.2, 1500),
                    (81530, 61101, None, 7.4, 1000)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = False)])


     correct_data = [("persona_con_mas_ingresos", 81530)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica2 = metrica_2(df)


     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica2.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica2.collect() == correct_df.collect()


# Unit Test 13: Métrica 2 Persona con más ingresos empate y datos faltantes

def test_metrica2_empate(spark_session):
     print("\n")
     print("Unit Test 13: Métrica 2 Persona con más ingresos empate y datos faltantes")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, None),
                    (45683, 20903, 40503, 10.0, 1000),
                    (45683, None, 60303, 8.0, 900),
                    (None, 50901, 11803, 19.8, 1300),
                    (93066, 61101, 51103, None, 1000),
                    (81530, 10602, 21202, None, 1000),
                    (81530, 21103, 11302, 5.0, 2000),
                    (81530, 61101, None, 12.0, 600)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = False)])


     correct_data = [("persona_con_mas_ingresos", 81530),
                    ("persona_con_mas_ingresos", 45683)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica2 = metrica_2(df)

     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica2.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica2.collect() == correct_df.collect()


# Métricas 3, 4 y 5


# Unit Test 14: Métricas 3, 4 y 5 - Percentiles 25, 50 y 75

def test_metricas345_completo(spark_session):
     print("\n")
     print("Unit Test 14: Métricas 3, 4 y 5 - Percentiles 25, 50 y 75 completo")
     print("\n")


     dataframe = [(93066, 21103, 11302, 7.6, 1500),
               (93066, 10602, 21202, 2.3, 1000),
               (45683, 61101, 51103, 7.4, 1000),
               (45683, 50901, 11803, 19.8, 1300), 
               (69251, 12001, 10901, 1.6, 1300), 
               (69251, 12001, 30803, 18.1, 800),
               (59201, 20903, 40503, 17.2, 1100),
               (59201, 40702, 10601, 12.2, 700)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', DoubleType(), nullable = True)])


     correct_data = [("percentil_25", 13700.0),
                    ("percentil_50", 16560.0),
                    ("percentil_75", 27460.0)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)


     metrica3 = metrica_3(df, spark_session)


     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica3.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica3.collect() == correct_df.collect()


# Unit Test 15: Métricas 3, 4 y 5 - Percentiles 25, 50 y 75 con NAs y pocos datos


def test_metricas345_NA_pocos_datos(spark_session):
     print("\n")
     print("Unit Test 15: Métricas 3, 4 y 5 - Percentiles 25, 50 y 75 con NAs y pocos datos")
     print("\n")


     dataframe = [(93066, 21103, 11302, None, 1500),
               (93066, 10602, 21202, 2.3, 1000),
               (45683, 61101, 51103, 7.4, None),
               (45683, 50901, 11803, 19.8, 1300)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros','Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', DoubleType(), nullable = True)])


     correct_data = [("percentil_25", 2300.0),
                    ("percentil_50", 2300.0),
                    ("percentil_75", 25740.0)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)


     metrica3 = metrica_3(df, spark_session)


         
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica3.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica3.collect() == correct_df.collect()


# Unit Test 16: Métrica 6 - código postal origen con más ingresos datos completos


def test_metrica6_completo(spark_session):
     print("\n")
     print("Unit Test 16: Métrica 6 - código postal origen con más ingresos datos completos")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, 800),
                    (45683, 20903, 40503, 17.2, 1100),
                    (45683, 10201, 60303, 4.9, 1200),
                    (93066, 50901, 11803, 19.8, 1300),
                    (93066, 61101, 51103, 7.4, 1000),
                    (81530, 10602, 21202, 2.3, 1000),
                    (81530, 21103, 11302, 7.6, 1500),
                    (81530, 61101, 51103, 7.4, 1000)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros', 'Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = True)])


     correct_data = [("codigo_postal_origen_con_mas_ingresos", 50901)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica6 = metrica_6(df)



     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica6.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica6.collect() == correct_df.collect()


# Unit Test 17: Métrica 6 - código postal origen con más ingresos datos faltantes


def test_metrica6_NA(spark_session):
     print("\n")
     print("Unit Test 17: Métrica 6 - código postal origen con más ingresos datos faltantes")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, None),
                    (None, 20903, 40503, 3.2, 1100),
                    (45683, None, 60303, 4.9, 1200),
                    (93066, 50901, 11803, None, None),
                    (93066, 61101, 51103, 7.4, 1000),
                    (81530, 10602, 21202, None, 1000),
                    (81530, 21103, None, 7.6, 1500),
                    (81530, 61101, 51103, 7.4, None)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros', 'Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = True)])


     correct_data = [("codigo_postal_origen_con_mas_ingresos", 21103)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica6 = metrica_6(df)


     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica6.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica6.collect() == correct_df.collect()



# Unit Test 18: Métrica 6 - código postal origen con más ingresos empate y datos faltantes


def test_metrica6_empate(spark_session):
     print("\n")
     print("Unit Test 18: Métrica 6 - código postal origen con más ingresos empate y datos faltantes")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, None),
                    (None, 20903, 40503, 3.2, 1100),
                    (45683, None, 60303, 4.9, 1200),
                    (93066, 50901, 11803, None, None),
                    (93066, 61101, 51103, 10.5, 1000),
                    (81530, 10602, 21202, None, 1000),
                    (81530, 21103, None, 7.0, 1500),
                    (81530, 61101, 51103, 7.4, None)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros', 'Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = False),
                         StructField('Valor', LongType(), nullable = True)])


     correct_data = [("codigo_postal_origen_con_mas_ingresos", 21103),
                    ("codigo_postal_origen_con_mas_ingresos", 61101)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica6 = metrica_6(df)


     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica6.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica6.collect() == correct_df.collect()


# Unit Test 19: Métrica 7 - código postal destino con más ingresos datos completos


def test_metrica7_completo(spark_session):
     print("\n")
     print("Unit Test 19: Métrica 7 - código postal destino con más ingresos datos completos")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, 800),
                    (45683, 20903, 40503, 17.2, 1100),
                    (45683, 10201, 60303, 4.9, 1200),
                    (93066, 50901, 11803, 19.8, 1300),
                    (93066, 61101, 51103, 7.4, 1000),
                    (81530, 10602, 21202, 2.3, 1000),
                    (81530, 21103, 11302, 7.6, 1500),
                    (81530, 61101, 51103, 7.4, 1000)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros', 'Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = False),
                         StructField('Valor', LongType(), nullable = True)])


     correct_data = [("codigo_postal_destino_con_mas_ingresos", 11803)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica7 = metrica_7(df)


     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica7.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica7.collect() == correct_df.collect()




# Unit Test 20: Métrica 7 - código postal destino con más ingresos datos faltantes


def test_metrica7_NA(spark_session):
     print("\n")
     print("Unit Test 20: Métrica 7 - código postal destino con más ingresos datos faltantes")
     print("\n")


     dataframe = [(45683, 12001, None, 18.1, 800),
                    (45683, 20903, 40503, 17.2, None),
                    (45683, None, 60303, 4.9, 1200),
                    (93066, 50901, 11803, 19.8, None),
                    (93066, 61101, None, 7.4, 1000),
                    (81530, 10602, 21202, 2.3, 1000),
                    (81530, 21103, 11302, 7.6, 1500),
                    (81530, 61101, 51103, None, None)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros', 'Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = False),
                         StructField('Valor', LongType(), nullable = True)])


     correct_data = [("codigo_postal_destino_con_mas_ingresos", 11302)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica7 = metrica_7(df)



     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica7.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica7.collect() == correct_df.collect()


# Unit Test 21: Métrica 7 - código postal destino con más ingresos empate y datos faltantes


def test_metrica7_empate_NA(spark_session):
     print("\n")
     print("Unit Test 21: Métrica 7 - código postal destino con más ingresos empate y datos faltantes")
     print("\n")


     dataframe = [(45683, 12001, 30803, 18.1, None),
                    (None, 20903, 40503, 17.0, 1200),
                    (45683, None, 60303, 4.9, 1200),
                    (93066, 50901, 11803, None, None),
                    (93066, 61101, 51103, 34.0, 600),
                    (81530, 10602, 21202, None, 1000),
                    (81530, 21103, None, 7.0, 1500),
                    (81530, 61101, 51103, 7.4, None)] 
                    

         
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros', 'Precio_kilometro'])


     

     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', LongType(), nullable = True)])


     correct_data = [("codigo_postal_destino_con_mas_ingresos", 40503),
                    ("codigo_postal_destino_con_mas_ingresos", 51103)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metrica7 = metrica_7(df)

     
     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()

     print("Output del código")
     metrica7.show()
     print("\n")
     print("-----------------------------------------------")


     assert metrica7.collect() == correct_df.collect()


# Unit test 22: Tabla con todas las métricas datos faltantes y empates


def test_todas_metricas_NA_empate(spark_session):
     print("\n")
     print("Unit Test 22: Tabla con todas las métricas datos faltantes y empates")
     print("\n")


     dataframe = [(45683, 12001, 30803, 8.4, 1250),
                    (None, 20903, 40503, 17.0, 1200),
                    (45683, None, 60303, 4.9, 1200),
                    (93066, 50901, 11803, None, None),
                    (93066, 61101, 51103, 34.0, 600),
                    (81530, 10602, 21202, None, 1000),
                    (81530, 21103, None, 7.0, 1500),
                    (81530, 61101, 51103, 7.4, None)] 

                              
     df  = spark_session.createDataFrame(dataframe, 
     ['Identificador', 'Codigo_postal_origen', 'Codigo_postal_destino', 'Kilometros', 'Precio_kilometro'])


     correct_dataframe_schema = StructType([StructField('Tipo_metrica', StringType(), nullable = True),
                         StructField('Valor', DoubleType(), nullable = True)])

     correct_data = [("persona_con_mas_km", 93066.0),
                    ("persona_con_mas_ingresos", 93066.0),
                    ("percentil_25", 10500.0),
                    ("percentil_50", 16380.0),
                    ("percentil_75", 20400.0),
                    ("codigo_postal_origen_con_mas_ingresos", 20903.0),
                    ("codigo_postal_origen_con_mas_ingresos", 61101.0),
                    ("codigo_postal_destino_con_mas_ingresos", 51103.0),
                    ("codigo_postal_destino_con_mas_ingresos", 40503.0)]

     correct_df = spark_session.createDataFrame(correct_data, correct_dataframe_schema)

     metricas = todas_metricas(df, spark_session)


     metricas.printSchema()


     print("-----------------------------------------------")
     print("Output esperado")
     correct_df.show()
     
     print("Output del código")
     metricas.show()
     print("\n")
     print("-----------------------------------------------")


     assert metricas.collect() == correct_df.collect()














