#!/bin/bash
docker build --tag tarea_2 .
