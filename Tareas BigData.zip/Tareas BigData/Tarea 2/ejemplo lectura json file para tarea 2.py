#!/usr/bin/env python
# coding: utf-8

# In[30]:


############################################################################################
#  Parte inicial como siempre lo hacemos
############################################################################################
import findspark
findspark.init()

import pyspark

from pyspark.sql import SparkSession

from pyspark.sql import functions as F

spark = SparkSession.builder.appName("ejemplo con json file").getOrCreate()

############################################################################################
#  Se lee el archivo y se muestra cómo queda
############################################################################################
df = spark.read.option("multiline","true").json("ejemplo.json")
df.printSchema()
df.show()

############################################################################################
#  Se requiere poner columnas por separado.
#  Si no conoce, puede investigar el explode
#  https://sparkbyexamples.com/pyspark/pyspark-explode-array-and-map-columns-to-rows/
############################################################################################
base =(df
    .select(F.explode('viajes'), 'identificador')
    .select(F.explode('col'), 'identificador')
    .withColumn('origen', F.col('col.origen') )
    .withColumn('destino', F.col('col.destino') )
    .withColumn('km', F.col('col.km') )
    .withColumn('precio', F.col('col.precio') )
    .drop('col')
    )

base.printSchema()
base.show()


# In[ ]:




