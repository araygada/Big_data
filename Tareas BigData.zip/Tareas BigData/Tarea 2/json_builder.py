
import json 
      
data ={}
data["id"]  = "120230592"
data["viajes"] = []

data["viajes"].append({"origen":"11504",
                        "destino":"11501",
                        "kilometros": 2.8,
                        "precio_km": 550})
data["viajes"].append({"origen":"11504",
                        "destino":"11501",
                        "kilometros": 2.8,
                        "precio_km": 550})


# Serializing json  
json_object = json.dumps(data, indent = 4) 
print(json_object)
print(type(json_object))

# guardar el archivo json
archivo = open('conductor01.json', 'w')
archivo.write(json_object)
archivo.close()

# leer el archivo json
archivo = open('conductor01.json', 'r')
datos = archivo.read()
print(datos)
archivo.close()
