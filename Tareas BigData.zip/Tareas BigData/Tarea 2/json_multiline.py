#!/usr/bin/env python
# coding: utf-8

# In[30]:


############################################################################################
#  Parte inicial como siempre lo hacemos
############################################################################################
import findspark
findspark.init()

import pyspark

from pyspark.sql import SparkSession

from pyspark.sql import functions as F

spark = SparkSession.builder.appName("ejemplo con json file").getOrCreate()

############################################################################################
#  Se lee el archivo y se muestra cómo queda
############################################################################################
df = spark.read.option("multiline","true").json(
    ["data/persona1b.json",
     "data/persona2b.json",
     "data/persona3b.json"
    ])


df.printSchema()
df.show()

############################################################################################
#  Se requiere poner columnas por separado.
#  Si no conoce, puede investigar el explode
#  https://sparkbyexamples.com/pyspark/pyspark-explode-array-and-map-columns-to-rows/
############################################################################################
base =(df
    .select(F.explode('viajes'), 'id')
    .select(F.explode('col'), 'id')
    .withColumn('origen', F.col('col.origen') )
    .withColumn('destino', F.col('col.destino') )
    .withColumn('kilometros', F.col('col.kilometros') )
    .withColumn('precio_km', F.col('col.precio_km') )
    .drop('col')
    )

base.printSchema()
base.show(100)


# In[ ]:




