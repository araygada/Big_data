#!/usr/bin/env python
# coding: utf-8

import findspark
findspark.init()

import pyspark

from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from pyspark.sql.functions import col, date_format, udf, sum, count, avg, mean, desc, asc, round, lit, percentile_approx, explode
from pyspark.sql import Window
from pyspark.sql.types import (DateType, IntegerType, FloatType, StructField,
                               StructType, TimestampType, StringType)

from funciones2 import joiner, aggregater, aggregater_top

spark = SparkSession.builder.appName("diber").getOrCreate()


# Carga inicial de datos
# ===================================================================================================

# Carga de json's de viajes conductores de Diver
# ---------------------------------------------------------------------------------------------------

df = spark.read.option("multiline","true").json(
    ["data/persona1.json",
     "data/persona2.json",
     "data/persona3.json"
    ])

df.printSchema()
df.show()

base =(df
    .select(F.explode('viajes'), 'id')
    .select(F.explode('col'), 'id')
    .withColumn('origen', F.col('col.origen') )
    .withColumn('destino', F.col('col.destino') )
    .withColumn('kilometros', F.col('col.kilometros') )
    .withColumn('precio_km', F.col('col.precio_km') )
    .drop('col')
    )

base.printSchema()
base.show()

df.show()


# Creación de dataframe con el total de cantidad de viajes origen y destino
# ===================================================================================================

# DataFrame intermedio de códigos postales de viaje origen
# ---------------------------------------------------------------------------------------------------
dataFrame = base
col_group = F.col('col.origen')
operacion = F.count
col_oper = "kilometros"
alias = "Q_viajes"
sort= desc
df_total_viajes_origen = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_total_viajes_origen = df_total_viajes_origen.withColumnRenamed("origen", "código")

df_total_viajes_origen = df_total_viajes_origen.withColumn("tipo_viaje", lit('origen')) 

df_total_viajes_origen.show()

# DataFrame intermedio de códigos postales de viaje destino
# ---------------------------------------------------------------------------------------------------
dataFrame = base
col_group = F.col('col.destino')
operacion = count
col_oper = "kilometros"
alias = "Q_viajes"
sort= desc
df_total_viajes_destino = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_total_viajes_destino = df_total_viajes_destino.withColumnRenamed("destino", "código")

df_total_viajes_destino = df_total_viajes_destino.withColumn("tipo_viaje", lit('destino')) 

df_total_viajes_destino.show()


# Unión de los data frames de viajes (origen y destino) en un solo data frame
# ---------------------------------------------------------------------------------------------------
df_total_viajes = df_total_viajes_origen.union(df_total_viajes_destino)
df_total_viajes = df_total_viajes.select('código', 'tipo_viaje', 'Q_viajes')
df_total_viajes.show(100)

# Imprime el dataframe en formato csv
df_total_viajes.coalesce(1).write \
    .format('csv') \
    .mode("overwrite") \
    .option("header", 'true') \
    .save('total_viajes.csv')



# Creación de dataframe con el total de ingresos de viajes origen y destino
# ===================================================================================================

# Agrega al dataframe base nueva columna  calculada con el ingreso por viaje (kilometros por precio_Km)
# ---------------------------------------------------------------------------------------------------
df_ingresos = base.withColumn('ingreso', df.kilometros * df.precio_km)

df_ingresos.show()

# DataFrame intermedio de códigos postales de total de ingresos de viajes origen
# ---------------------------------------------------------------------------------------------------
dataFrame = df_ingresos
col_group = "origen"
operacion = sum
col_oper = "ingreso"
alias = "T_ingresos"
sort= desc
df_total_ingresos_origen = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_total_ingresos_origen = df_total_ingresos_origen.withColumnRenamed("origen", "código")

df_total_ingresos_origen = df_total_ingresos_origen.withColumn("tipo_viaje", lit('origen')) 
df_total_ingresos_origen = df_total_ingresos_origen.select('código', 'tipo_viaje', 'T_ingresos')
df_total_ingresos_origen.show()

# DataFrame intermedio de códigos postales de total de ingresos de viaje destino
# ---------------------------------------------------------------------------------------------------
dataFrame = df_ingresos
col_group = "destino"
operacion = sum
col_oper = "ingreso"
alias = "T_ingresos"
sort= desc
df_total_ingresos_destino = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_total_ingresos_destino = df_total_ingresos_destino.withColumnRenamed("destino", "código")

df_total_ingresos_destino = df_total_ingresos_destino.withColumn("tipo_viaje", lit('destino')) 
df_total_ingresos_destino = df_total_ingresos_destino.select('código', 'tipo_viaje', 'T_ingresos')
df_total_ingresos_destino.show()

# Unión de los data frames de viajes (origen y destino) en un solo data frame
# ---------------------------------------------------------------------------------------------------
df_total_ingresos = df_total_ingresos_origen.union(df_total_ingresos_destino)
df_total_ingresos.show(100)

# Imprime el dataframe en formato csv
df_total_ingresos.coalesce(1).write \
    .format('csv') \
    .mode("overwrite") \
    .option("header", 'true') \
    .save('total_ingresos.csv')


# Determinación de métricas y del archivo resumen metricas.csv
# ===================================================================================================

# Crea schema del dataframe de metricas
# ---------------------------------------------------------------------------------------------------
data_schema = StructType([StructField("metrica", StringType(), True),
               StructField("valor", StringType(), True),
              ])

# Crea lista de metricas
# ---------------------------------------------------------------------------------------------------
lista_metricas = []

# Métrica 1: Persona con más kilómetros
# ---------------------------------------------------------------------------------------------------

# DataFrame resumen de kilometros por persona
dataFrame = base
col_group = "id"
operacion = sum
col_oper = "kilometros"
alias = "T_kilometros"
sort= desc
top = 1

df_total_personas_kms = aggregater_top(dataFrame, col_group, operacion, col_oper, alias, sort, top)

df_total_personas_kms.show()

persona_max_km = df_total_personas_kms.collect()[0][0]

lista_metricas.append(("persona_max_km",persona_max_km))
print(lista_metricas)


# Métrica 2: Persona con más ingresos
# ---------------------------------------------------------------------------------------------------

# DataFrame resumen de ingresos por persona
dataFrame = df_ingresos
col_group = "id"
operacion = sum
col_oper = "ingreso"
alias = "T_ingreso"
sort= desc
top = 1

df_total_personas_ingreso_top = aggregater_top(dataFrame, col_group, operacion, col_oper, alias, sort, top)

df_total_personas_ingreso_top.show()

persona_max_ingreso = df_total_personas_ingreso_top.collect()[0][0]

lista_metricas.append(("persona_max_ing", persona_max_ingreso))

print('\n' + "="*80)
print(lista_metricas)
print('\n' + "="*80)


# Métrica 3: Percentil 25 de ingresos por persona
# ---------------------------------------------------------------------------------------------------

# DataFrame resumen de ingresos por persona
dataFrame = df_ingresos
col_group = "id"
operacion = sum
col_oper = "ingreso"
alias = "T_ingreso"
sort= asc
top = 1

df_total_personas_ingreso = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)

df_total_personas_ingreso.show()

df_percentil_25 = df_total_personas_ingreso.select(percentile_approx("T_ingreso", 0.25, 1000000).alias("percentil_25"))
df_percentil_25.show()
percentil_25 = df_percentil_25.collect()[0][0]

print("\nPercentil 25")
print("="*80)
print(percentil_25)
print("="*80 + '\n')

lista_metricas.append(("percentil_25", percentil_25))

print("\nLista de métricas actualizada")
print("="*80)
print(lista_metricas)
print("="*80 + '\n')


# Métrica 4: Percentil 50 de ingresos por persona
# ---------------------------------------------------------------------------------------------------

df_percentil_50 = df_total_personas_ingreso.select(percentile_approx("T_ingreso", 0.50, 1000000).alias("percentil_50"))
df_percentil_50.show()
percentil_50 = df_percentil_50.collect()[0][0]

print("\nPercentil 50")
print("="*80)
print(percentil_50)
print("="*80 + '\n')

lista_metricas.append(("percentil_50", percentil_50))

print("\nLista de métricas actualizada")
print("="*80)
print(lista_metricas)
print("="*80 + '\n')

# Métrica 5: Percentil 75 de ingresos por persona
# ---------------------------------------------------------------------------------------------------

df_percentil_75 = df_total_personas_ingreso.select(percentile_approx("T_ingreso", 0.75, 1000000).alias("percentil_75"))
df_percentil_75.show()
percentil_75 = df_percentil_75.collect()[0][0]

print("\nPercentil 75")
print("="*80)
print(percentil_75)
print("="*80 + '\n')

lista_metricas.append(("percentil_75", percentil_75))

print("\nLista de métricas actualizada")
print("="*80)
print(lista_metricas)
print("="*80 + '\n')


# Métrica 6: Código postal con mayor ingreso
# ---------------------------------------------------------------------------------------------------

origen_max_ingreso = df_total_ingresos_origen.collect()[0][0]

print("\norigen_max_ingreso")
print("="*80)
print(origen_max_ingreso)
print("="*80 + '\n')

lista_metricas.append(("origen_max_ingreso", origen_max_ingreso))

print("\nLista de métricas actualizada")
print("="*80)
print(lista_metricas)
print("="*80 + '\n')


# Métrica 7: Código postal destino con mayor ingreso
# ---------------------------------------------------------------------------------------------------

destino_max_ingreso = df_total_ingresos_destino.collect()[0][0]

print("\ndestino_max_ingreso")
print("="*80)
print(destino_max_ingreso)
print("="*80 + '\n')

lista_metricas.append(("destino_max_ingreso", destino_max_ingreso))

print("\nLista de métricas actualizada")
print("="*80)
print(lista_metricas)
print("="*80 + '\n')


# Crea dataframe de metricas
# ---------------------------------------------------------------------------------------------------
df_metricas = spark.createDataFrame(data = lista_metricas, schema = data_schema)
df_metricas.show()

