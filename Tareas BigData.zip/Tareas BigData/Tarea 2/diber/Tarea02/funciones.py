# Este archivo contiene las funciones a utilizar en la Tarea01 sobre ciclismo
from datetime import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, date_format, udf, sum, count, avg, mean, desc, asc, round, lit, percentile_approx, explode
from pyspark.sql import Window
from pyspark.sql.types import (DateType, IntegerType, FloatType, StructField,
                               StructType, TimestampType, StringType)

# spark = SparkSession.builder.appName("Funciones").getOrCreate()


def aggregater(dataFrame, col_group, operacion, col_oper, alias, sort):
    # col_group => columna para el groupBy
    # col_oper   => columna a operar
    # operacion  => tipo de operación a aplicar (p.e sum, avg)
    # sort       => tipo de ordenamiento (p.e. desc)
    df_aggregated = dataFrame.groupBy(col_group) \
                    .agg(round(operacion(col_oper),2).alias(alias)) \
                    .sort(sort(alias))

    return df_aggregated


def total_viajes(dataFrame, col_group1, col_group2, col_oper, alias, sort):
    # Función para la creación de archivo de total de viajes por código postal
    # ===================================================================================================
    # col_group1  => columna para el groupBy para origen
    # col_group2  => columna para el groupBy para destino
    # col_oper    => columna a operar en cuanto a la función escogida (p.e. sum, avg, count)
    # sort        => tipo de ordenamiento (p.e. desc)

    # DataFrame intermedio de códigos postales de viaje origen
    # ---------------------------------------------------------------------------------------------------

    df_total_viajes_origen = dataFrame.groupBy(col_group1) \
                                .agg(round(count(col_oper),2).alias(alias)) \
                                .sort(sort(alias))

    df_total_viajes_origen = df_total_viajes_origen.withColumnRenamed("origen", "código")
    df_total_viajes_origen = df_total_viajes_origen.withColumn("tipo_viaje", lit('origen'))

    # DataFrame intermedio de códigos postales de viaje destino
    # ---------------------------------------------------------------------------------------------------
    df_total_viajes_destino = dataFrame.groupBy(col_group2) \
                                .agg(round(count(col_oper),2).alias(alias)) \
                                .sort(sort(alias))

    df_total_viajes_destino = df_total_viajes_destino.withColumnRenamed("destino", "código")
    df_total_viajes_destino = df_total_viajes_destino.withColumn("tipo_viaje", lit('destino')) 

    # Unión de los data frames de viajes (origen y destino) en un solo data frame
    # ---------------------------------------------------------------------------------------------------
    df_total_viajes = df_total_viajes_origen.union(df_total_viajes_destino)
    df_total_viajes = df_total_viajes.select('código', 'tipo_viaje', 'Q_viajes')
    df_total_viajes = df_total_viajes.sort(col("código").asc())

    return df_total_viajes


def total_ingresos(dataFrame, col_group1, col_group2, col_oper, alias, sort):
    # Función para la creación de archivo de total de ingresos por código postal
    # ===================================================================================================
    # col_group1  => columna para el groupBy para origen
    # col_group2  => columna para el groupBy para destino
    # col_oper    => columna a operar en cuanto a la función seleccionada (p.e. sum, avg, count)
    # sort        => tipo de ordenamiento (p.e. desc)

    # DataFrame intermedio de códigos postales de ingresos por origen
    # ---------------------------------------------------------------------------------------------------

    df_total_ingresos_origen = dataFrame.groupBy(col_group1) \
                                .agg(round(sum(col_oper),2).alias(alias)) \
                                .sort(sort(alias))

    df_total_ingresos_origen = df_total_ingresos_origen.withColumnRenamed("origen", "código")
    df_total_ingresos_origen = df_total_ingresos_origen.withColumn("tipo_viaje", lit('origen')) 

    # DataFrame intermedio de códigos postales de ingresos por destino
    # ---------------------------------------------------------------------------------------------------
    df_total_ingresos_destino = dataFrame.groupBy(col_group2) \
                                .agg(round(sum(col_oper),2).alias(alias)) \
                                .sort(sort(alias))

    df_total_ingresos_destino = df_total_ingresos_destino.withColumnRenamed("destino", "código")
    df_total_ingresos_destino = df_total_ingresos_destino.withColumn("tipo_viaje", lit('destino')) 

    # Unión de los data frames de ingresos (origen y destino) en un solo data frame
    # ---------------------------------------------------------------------------------------------------
    df_total_ingresos = df_total_ingresos_origen.union(df_total_ingresos_destino)
    df_total_ingresos = df_total_ingresos.select('código', 'tipo_viaje', 'T_ingresos')
    df_total_ingresos = df_total_ingresos.sort(col("código").asc())


    return df_total_ingresos


def metrica_persona_max_km(dataFrame, col_group, operacion, col_oper, alias, sort, nTop):
    # Función para la determinación de la métrica de persona con el mayor kilometraje
    # ====================================================================================
    # col_group  => columna para el groupBy
    # col_oper   => columna a operar
    # operacion  => tipo de operación a aplicar (p.e sum, avg)
    # sort       => tipo de ordenamiento (p.e. desc)
    # col_filter => columna a filtrar
    # filter     => Elemento a filtrar
    # nTop       => Número del top que se quiere mostrar (p.e. top 2)

    df_aggregated = dataFrame.groupBy(col_group) \
                    .agg(round(operacion(col_oper),2).alias(alias)) \
                    .sort(sort(alias))
                    
    df_total_personas_kms = df_aggregated.limit(nTop)
    
    df_total_personas_kms.show(50)

    persona_max_km = df_total_personas_kms.collect()[0][0]

    return persona_max_km


def metrica_persona_max_ingreso(dataFrame, col_group, operacion, col_oper, alias, sort, nTop):
    # Función para la determinación de la métrica de persona con el mayor ingreso
    # ============================================================================
    # col_group  => columna para el groupBy
    # col_oper   => columna a operar
    # operacion  => tipo de operación a aplicar (p.e sum, avg)
    # sort       => tipo de ordenamiento (p.e. desc)
    # col_filter => columna a filtrar
    # filter     => Elemento a filtrar
    # nTop       => Número del top que se quiere mostrar (p.e. top 2)

    df_aggregated = dataFrame.groupBy(col_group) \
                    .agg(round(operacion(col_oper),2).alias(alias)) \
                    .sort(sort(alias))
                    
    df_total_personas_ingreso_top = df_aggregated.limit(nTop)
    
    df_total_personas_ingreso_top.show(50)

    persona_max_ingreso = df_total_personas_ingreso_top.collect()[0][0]

    return persona_max_ingreso


def metrica_percentil(dataFrame, col_oper, percentil, alias):
    # Función para la determinación del percentil indicado sobre los ingresos
    # ========================================================================
    # col_oper   => Nombre de la columna sobre la que se calcula el percentil
    # percentile => Número decimal de percentil a calcular (p.e. 0.25, 0.50, 0.75)

    df_percentil = dataFrame.select(percentile_approx(col_oper, percentil, 1000000).alias(alias))
    df_percentil.show(50)
    percentil_25 = df_percentil.collect()[0][0]

    return percentil_25


def metrica_max_ingreso(dataFrame, col_filter, filter, col_oper):
    
    df_total_ingresos_filtrado = dataFrame.where(col(col_filter) == filter)
    df_total_ingresos_ordenado = df_total_ingresos_filtrado.sort(col(col_oper).desc())
    origen_max_ingreso = df_total_ingresos_ordenado.collect()[0][0]

    return origen_max_ingreso

    


