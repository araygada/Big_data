#!/usr/bin/env python
# coding: utf-8

import findspark
findspark.init()

import pyspark

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from pyspark.sql.functions import (col, date_format, udf, sum, count, avg, mean, desc, asc,
                                    round, lit, percentile_approx, explode)

from pyspark.sql import Window
from pyspark.sql.types import (DateType, IntegerType, FloatType, StructField,
                               StructType, TimestampType, StringType)

from funciones import (total_viajes, total_ingresos, metrica_persona_max_km, metrica_persona_max_ingreso,
                        metrica_percentil, metrica_max_ingreso, aggregater)

spark = SparkSession.builder.appName("diber").getOrCreate()


# Carga inicial de datos
# ===================================================================================================

# Carga de json's de viajes conductores de Diver
# ---------------------------------------------------------------------------------------------------

df = spark.read.option("multiline","true").json(
    ["data/persona1.json",
     "data/persona2.json",
     "data/persona3.json",
     "data/persona4.json",
     "data/persona5.json"     
    ])

df.printSchema()
df.show()

base =(df
    .select(explode('viajes'), 'id')
    .select(explode('col'), 'id')
    .withColumn('origen', col('col.origen') )
    .withColumn('destino', col('col.destino') )
    .withColumn('kilometros', col('col.kilometros') )
    .withColumn('precio_km', col('col.precio_km') )
    .drop('col')
    )

base.printSchema()
base.show(50)



# Creación de dataframe con el total de cantidad de viajes origen y destino
# ===================================================================================================

dataFrame = base
col_group1 = "origen"
col_group2 = "destino"
col_oper = "kilometros"
alias = "Q_viajes"
sort= desc

df_total_viajes = total_viajes(dataFrame, col_group1, col_group2, col_oper, alias, sort)
df_total_viajes.show(50)

# Genera archivo del dataframe en formato csv
df_total_viajes.coalesce(1).write \
    .format('csv') \
    .mode("overwrite") \
    .option("header", 'true') \
    .save("total_viajes.csv")




# Creación de dataframe con el total de ingresos de viajes origen y destino
# ===================================================================================================

# Agrega al dataframe base nueva columna  calculada con el ingreso por viaje (kilometros por precio_Km)
# ----------------------------------------------------------------------------------------------------
df_ingresos = base.withColumn('ingreso', base.kilometros * base.precio_km)
df_ingresos.show(50)

dataFrame = df_ingresos
col_group1 = "origen"
col_group2 = "destino"
col_oper = "ingreso"
alias = "T_ingresos"
sort= desc

df_total_ingresos = total_ingresos(dataFrame, col_group1, col_group2, col_oper, alias, sort)
df_total_ingresos.show(50)

# Genera archivo del dataframe en formato csv
df_total_ingresos.coalesce(1).write \
    .format('csv') \
    .mode("overwrite") \
    .option("header", 'true') \
    .save("total_ingresos.csv")



# Determinación de métricas y del archivo resumen metricas.csv
# ===================================================================================================

# Crea schema del dataframe de metricas
# ---------------------------------------------------------------------------------------------------
data_schema = StructType([StructField("metrica", StringType(), True),
               StructField("valor", StringType(), True),
              ])

# Crea lista de metricas
# ---------------------------------------------------------------------------------------------------
lista_metricas = []

# Métrica 1: Persona con más kilómetros
# ---------------------------------------------------------------------------------------------------

dataFrame = base
col_group = "id"
operacion = sum
col_oper = "kilometros"
alias = "T_kilometros"
sort= desc
top = 1

persona_max_km = metrica_persona_max_km(dataFrame, col_group, operacion, col_oper, alias, sort, top)

lista_metricas.append(("persona_max_km",persona_max_km))

print('\n' + "="*80)
print(lista_metricas)
print('\n' + "="*80)


# Métrica 2: Persona con más ingresos
# ---------------------------------------------------------------------------------------------------

# DataFrame resumen de ingresos por persona
dataFrame = df_ingresos
col_group = "id"
operacion = sum
col_oper = "ingreso"
alias = "T_ingreso"
sort= desc
top = 1

persona_max_ingreso = metrica_persona_max_ingreso(dataFrame, col_group, operacion, col_oper, alias, sort, top)

lista_metricas.append(("persona_max_ing", persona_max_ingreso))

print('\n' + "="*80)
print(lista_metricas)
print('\n' + "="*80)


# Métrica 3: Percentil 25 de ingresos por persona
# ---------------------------------------------------------------------------------------------------

# DataFrame resumen de ingresos por persona
dataFrame = df_ingresos
col_group = "id"
operacion = sum
col_oper = "ingreso"
alias = "T_ingreso"
sort= asc
top = 1

df_total_personas_ingreso = aggregater(dataFrame, col_group, operacion, col_oper, alias, sort)
df_total_personas_ingreso.show()

# Cálculo del percentil 25
dataFrame = df_total_personas_ingreso
col_oper = "T_ingreso"
percentil = 0.25
alias = "percentil_25"

percentil_25 = metrica_percentil(dataFrame, col_oper, percentil, alias)

print("\nPercentil 25")
print("="*80)
print(percentil_25)
print("="*80 + '\n')

lista_metricas.append(("percentil_25", percentil_25))


# Métrica 4: Percentil 50 de ingresos por persona
# ---------------------------------------------------------------------------------------------------

dataFrame = df_total_personas_ingreso
col_oper = "T_ingreso"
percentil = 0.5
alias = "percentil_50"

percentil_50 = metrica_percentil(dataFrame, col_oper, percentil, alias)

print("\nPercentil 50")
print("="*80)
print(percentil_50)
print("="*80 + '\n')

lista_metricas.append(("percentil_50", percentil_50))


# Métrica 5: Percentil 75 de ingresos por persona
# ---------------------------------------------------------------------------------------------------

dataFrame = df_total_personas_ingreso
col_oper = "T_ingreso"
percentil = 0.75
alias = "percentil_75"

percentil_75 = metrica_percentil(dataFrame, col_oper, percentil, alias)

print("\nPercentil 75")
print("="*80)
print(percentil_75)
print("="*80 + '\n')

lista_metricas.append(("percentil_75", percentil_75))


# Métrica 6: Código postal origen con mayor ingreso
# ---------------------------------------------------------------------------------------------------

dataFrame = df_total_ingresos
col_filter = "tipo_viaje"
filter = "origen"
col_oper = "T_ingresos"

origen_max_ingreso = metrica_max_ingreso(dataFrame, col_filter, filter, col_oper)

print("\norigen_max_ingreso")
print("="*80)
print(origen_max_ingreso)
print("="*80 + '\n')

lista_metricas.append(("origen_max_ingreso", origen_max_ingreso))



# Métrica 7: Código postal destino con mayor ingreso
# ---------------------------------------------------------------------------------------------------

dataFrame = df_total_ingresos
col_filter = "tipo_viaje"
filter = "destino"
col_oper = "T_ingresos"

destino_max_ingreso = metrica_max_ingreso(dataFrame, col_filter, filter, col_oper)

print("\ndestino_max_ingreso")
print("="*80)
print(destino_max_ingreso)
print("="*80 + '\n')

lista_metricas.append(("destino_max_ingreso", destino_max_ingreso))


# Crea dataframe de metricas
# ---------------------------------------------------------------------------------------------------
df_metricas = spark.createDataFrame(data = lista_metricas, schema = data_schema)
df_metricas.show()

# Genera archivo del dataframe en formato csv
df_metricas.coalesce(1).write \
    .format('csv') \
    .mode("overwrite") \
    .option("header", 'true') \
    .save("metricas.csv")