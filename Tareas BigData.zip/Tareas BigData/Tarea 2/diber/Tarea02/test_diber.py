import pytest
from pyspark.sql import types as T

from .funciones import *

# Test 1
# ---------------------------------------------------------------------------------------------
def test_total_viajes_01(spark_session):
    viajes_data =  [("700900134",70101,70103, 32.0, 600),
                    ("207900422",10202,10305, 15.2, 500),
                    ("110570949",10101,10107, 25.0, 450),
                    ("120230592",10101,10301, 6.2, 450),
                    ("111720927",60115,10107, 85.7, 550),
                    ]

    viajes_df = spark_session.createDataFrame(viajes_data,
                        ['id', 'origen', 'destino', 'kilometros', 'precio_km'])       
    viajes_df.show()

    col_group1 = 'origen'
    col_group2 = 'destino'
    col_oper = 'kilometros'
    alias = 'Q_viajes'
    sort= desc

    actual_ds = total_viajes(viajes_df, col_group1, col_group2, col_oper, alias, sort)

    expected_ds = spark_session.createDataFrame(
        [
            (10101,'origen',2),
            (10107,'destino',2),
            (10202,'origen',1),
            (10301,'destino',1),
            (10305,'destino',1),
            (60115,'origen',1),
            (70101,'origen',1),
            (70103,'destino',1),
        ],
        ['código','tipo_viaje','Q_viajes'])

    assert actual_ds.collect() == expected_ds.collect()


# Test 2
# ---------------------------------------------------------------------------------------------
def test_total_viajes_02(spark_session):
    viajes_data =  [("700900134",70101,70103, 32.0, 600), # Prueba con solo 2 líneas
                    ("207900422",10202,10305, 15.2, 500),
                    ]

    viajes_df = spark_session.createDataFrame(viajes_data,
                        ['id', 'origen', 'destino', 'kilometros', 'precio_km'])       
    viajes_df.show()

    col_group1 = 'origen'
    col_group2 = 'destino'
    col_oper = 'kilometros'
    alias = 'Q_viajes'
    sort= desc

    actual_ds = total_viajes(viajes_df, col_group1, col_group2, col_oper, alias, sort)

    expected_ds = spark_session.createDataFrame(
        [
            (10202,'origen',1),
            (10305,'destino',1),
            (70101,'origen',1),
            (70103,'destino',1),
        ],
        ['código','tipo_viaje','Q_viajes'])

    assert actual_ds.collect() == expected_ds.collect()


# Test 3
# ---------------------------------------------------------------------------------------------
def test_total_ingresos_01(spark_session):
    ingresos_data = [("111720927", 60115, 10107, 85.7, 550, 47135),
                    ("120230592", 10101, 10301, 6.2, 450, 2790),
                    ("700900134", 70101, 70103, 32.0, 600, 19200),
                    ]

    ingresos_df = spark_session.createDataFrame(ingresos_data,
                        ['id', 'origen', 'destino', 'kilometros', 'precio_km', 'ingreso'])       
    ingresos_df.show()

    col_group1 = "origen"
    col_group2 = "destino"
    col_oper = "ingreso"
    alias = 'T_ingresos'
    sort= desc

    actual_ds = total_ingresos(ingresos_df, col_group1, col_group2, col_oper, alias, sort)

    expected_ds = spark_session.createDataFrame(
        [
        (10101,"origen", 2790),
        (10107,"destino", 47135),
        (10301,"destino", 2790),
        (60115,"origen", 47135),
        (70101,"origen", 19200),
        (70103,"destino", 19200),
        ],
        ['código', 'tipo_viaje', 'T_ingresos'])

    assert actual_ds.collect() == expected_ds.collect()

# Test 4
# ---------------------------------------------------------------------------------------------
def test_total_ingresos_02(spark_session):
    ingresos_data = [("111720927", 60115, 10107, 85.7, 550000000, 47135000000), # Prueba con montos altos
                    ("120230592", 10101, 10301, 6.2, 450000000, 2790000000),
                    ("700900134", 70101, 70103, 32.0, 600000000, 19200000000),
                    ]

    ingresos_df = spark_session.createDataFrame(ingresos_data,
                        ['id', 'origen', 'destino', 'kilometros', 'precio_km', 'ingreso'])       
    ingresos_df.show()

    col_group1 = "origen"
    col_group2 = "destino"
    col_oper = "ingreso"
    alias = 'T_ingresos'
    sort= desc

    actual_ds = total_ingresos(ingresos_df, col_group1, col_group2, col_oper, alias, sort)

    expected_ds = spark_session.createDataFrame(
        [
        (10101,"origen", 2790000000),
        (10107,"destino", 47135000000),
        (10301,"destino", 2790000000),
        (60115,"origen", 47135000000),
        (70101,"origen", 19200000000),
        (70103,"destino", 19200000000),
        ],
        ['código', 'tipo_viaje', 'T_ingresos'])

    assert actual_ds.collect() == expected_ds.collect()


# Test 5
# ---------------------------------------------------------------------------------------------
def test_persona_max_km_01(spark_session):

    viajes_data =  [(700900134, 70101, 70103, 32.0, 600),
                    (207900422, 10202, 10305, 15.2, 500),
                    (110570949, 10101, 10107, 25.0, 450),
                    (120230592, 10101, 10301, 6.2, 450),
                    (111720927, 60115, 10107, 85.7, 550),
                    ]

    viajes_df = spark_session.createDataFrame(viajes_data,
                        ['id', 'origen', 'destino', 'kilometros', 'precio_km'])       
    viajes_df.show()

    col_group = "id"
    operacion = sum
    col_oper = "kilometros"
    alias = "T_kilometros"
    sort= desc
    top = 1

    actual_ds = metrica_persona_max_km(viajes_df, col_group, operacion, col_oper, alias, sort, top)

    expected_ds = 111720927

    assert actual_ds == expected_ds


# Test 6
# ---------------------------------------------------------------------------------------------
def test_persona_max_km_02(spark_session):

    viajes_data =  [(700900134, 70101, 70103, -32.0, 600), # Prueba con valores negativos
                    (207900422, 10202, 10305, -15.2, 500),
                    (110570949, 10101, 10107, -25.0, 450),
                    (120230592, 10101, 10301, -6.2, 450),
                    (111720927, 60115, 10107, -85.7, 550),
                    ]

    viajes_df = spark_session.createDataFrame(viajes_data,
                        ['id', 'origen', 'destino', 'kilometros', 'precio_km'])       
    viajes_df.show()

    col_group = "id"
    operacion = sum
    col_oper = "kilometros"
    alias = "T_kilometros"
    sort= desc
    top = 1

    actual_ds = metrica_persona_max_km(viajes_df, col_group, operacion, col_oper, alias, sort, top)

    expected_ds = 120230592

    assert actual_ds == expected_ds


# Test 7
# ---------------------------------------------------------------------------------------------
def test_persona_max_ingreso_01(spark_session):

    ingresos_data = [(111720927, 60115, 10107, 85.7, 550, 47135),
                    (120230592, 10101, 10301, 6.2, 450, 2790),
                    (700900134, 70101, 70103, 32.0, 600, 19200),
                    ]

    df_ingresos = spark_session.createDataFrame(ingresos_data,
                        ['id', 'origen', 'destino', 'kilometros', 'precio_km', 'ingreso'])       
    df_ingresos.show()

    col_group = "id"
    operacion = sum
    col_oper = "ingreso"
    alias = "T_ingreso"
    sort= desc
    top = 1

    actual_ds = metrica_persona_max_ingreso(df_ingresos, col_group, operacion, col_oper, alias, sort, top)

    expected_ds = 111720927

    assert actual_ds == expected_ds

# Test 8
# ---------------------------------------------------------------------------------------------
def test_persona_max_ingreso_02(spark_session):

    ingresos_data = [(111720927, 60115, 10107, 85.7, -550, -47135), # Prueba con valores negativos
                    (120230592, 10101, 10301, 6.2, -450, -2790),
                    (700900134, 70101, 70103, 32.0, -600, -19200),
                    ]

    df_ingresos = spark_session.createDataFrame(ingresos_data,
                        ['id', 'origen', 'destino', 'kilometros', 'precio_km', 'ingreso'])       
    df_ingresos.show()

    col_group = "id"
    operacion = sum
    col_oper = "ingreso"
    alias = "T_ingreso"
    sort= desc
    top = 1

    actual_ds = metrica_persona_max_ingreso(df_ingresos, col_group, operacion, col_oper, alias, sort, top)

    expected_ds = 120230592

    assert actual_ds == expected_ds


# Test 9
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil25_01(spark_session):

    total_ingresos_data =   [(120230592, 78077.0),
                            (110570949, 95091.0),
                            (207900422, 100514.9),
                            (111720927, 124391.5),
                            (700900134, 203591.5),
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.25
    alias = "percentil_25"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 95091

    assert actual_ds == expected_ds


# Test 10
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil25_02(spark_session):

    total_ingresos_data =   [(120230592, 78077.0),
                            (110570949, 95091.0),
                            (207900422, 100514.9),
                            (111720927, 124391.5),
                            (700900134, -203591.5), #Prueba con valores negativos
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.25
    alias = "percentil_25"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 78077.0

    assert actual_ds == expected_ds


# Test 11
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil25_03(spark_session):

    total_ingresos_data =   [(120230592, 78077.0),
                            (110570949, 95091.0),
                            (207900422, 0.0), # Prueba con valores en cero
                            (111720927, 124391.5),
                            (700900134, 203591.5), 
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.25
    alias = "percentil_25"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 78077.0

    assert actual_ds == expected_ds


# Test 12
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil50_01(spark_session):

    total_ingresos_data =   [(120230592, 78077.0),
                            (110570949, 95091.0),
                            (207900422, 100514.9),
                            (111720927, 124391.5),
                            (700900134, 203591.5),
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.50
    alias = "percentil_50"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 100514.9

    assert actual_ds == expected_ds


# Test 13
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil50_02(spark_session):

    total_ingresos_data =   [(120230592, 78077.0),
                            (110570949, 95091.0),
                            (207900422, 100514.9),
                            (111720927, 124391.5),
                            (700900134, -203591.5), # Prueba con valores negativos
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.50
    alias = "percentil_50"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 95091.0

    assert actual_ds == expected_ds

# Test 14
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil50_03(spark_session):

    total_ingresos_data =   [(120230592, 78077.0),
                            (110570949, 0.0), # Prueba con valores en cero
                            (207900422, 100514.9),
                            (111720927, 124391.5),
                            (700900134, 203591.5),
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.50
    alias = "percentil_50"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 100514.9

    assert actual_ds == expected_ds


# Test 15
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil75_01(spark_session):

    total_ingresos_data =   [(120230592, 78077.0),
                            (110570949, 95091.0),
                            (207900422, 100514.9),
                            (111720927, 124391.5),
                            (700900134, 203591.5),
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.75
    alias = "percentil_75"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 124391.5

    assert actual_ds == expected_ds


# Test 16
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil75_02(spark_session):

    total_ingresos_data =   [(120230592, 78077.0),
                            (110570949, 95091.0),
                            (207900422, 100514.9),
                            (111720927, 124391.5),
                            (700900134, -203591.5), # Prueba con valores negativos
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.75
    alias = "percentil_75"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 100514.9

    assert actual_ds == expected_ds

# Test 17
# ---------------------------------------------------------------------------------------------
def test_metrica_percentil75_03(spark_session):

    total_ingresos_data =   [(120230592, 0.0),  # Prueba con valores en cero
                            (110570949, 95091.0),
                            (207900422, 100514.9),
                            (111720927, 124391.5),
                            (700900134, 203591.5), 
                            ]

    df_ingresos = spark_session.createDataFrame(total_ingresos_data,
                        ['id', 'T_ingreso'])       
    df_ingresos.show()

    col_oper = "T_ingreso"
    percentil = 0.75
    alias = "percentil_75"

    actual_ds = metrica_percentil(df_ingresos, col_oper, percentil, alias)

    expected_ds = 124391.5

    assert actual_ds == expected_ds
