#!/bin/bash
docker build --tag diber .
